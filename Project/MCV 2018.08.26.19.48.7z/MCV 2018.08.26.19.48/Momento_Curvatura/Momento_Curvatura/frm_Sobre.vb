﻿Public Class frm_Sobre
    Private Sub frm_Sobre_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lbl1.Left = (lbl1.Parent.Width \ 2) - (lbl1.Width \ 2)
        lbl1.Top = 160

        lbl15.Left = (lbl15.Parent.Width \ 2) - (lbl15.Width \ 2)
        lbl15.Top = 180

        lbl2.Left = (lbl2.Parent.Width \ 2) - (lbl2.Width \ 2)
        lbl2.Top = 200

        lbl3.Left = (lbl3.Parent.Width \ 2) - (lbl3.Width \ 2)
        lbl3.Top = 240

        lbl4.Left = (lbl4.Parent.Width \ 2) - (lbl4.Width \ 2)
        lbl4.Top = 260

        lbl5.Left = (lbl5.Parent.Width \ 2) - (lbl5.Width \ 2)
        lbl5.Top = 300

        lbl6.Left = (lbl6.Parent.Width \ 2) - (lbl6.Width \ 2)
        lbl6.Top = 320

        lbl7.Left = (lbl7.Parent.Width \ 2) - (lbl7.Width \ 2)
        lbl7.Top = 340

        lbl8.Left = (lbl8.Parent.Width \ 2) - (lbl8.Width \ 2)
        lbl8.Top = 380

        lbl9.Left = (lbl9.Parent.Width \ 2) - (lbl9.Width \ 2)
        lbl9.Top = 420

        lbl10.Left = (lbl10.Parent.Width \ 2) - (lbl10.Width \ 2)
        lbl10.Top = 440

        lbl11.Left = (lbl11.Parent.Width \ 2) - (lbl11.Width \ 2)
        lbl11.Top = 460

        lbl12.Left = (lbl12.Parent.Width \ 2) - (lbl12.Width \ 2)
        lbl12.Top = 480

        lbl13.Left = (lbl13.Parent.Width \ 2) - (lbl13.Width \ 2)
        lbl13.Top = 500

        lbl14.Left = (lbl14.Parent.Width \ 2) - (lbl14.Width \ 2)
        lbl14.Top = 520


    End Sub

End Class