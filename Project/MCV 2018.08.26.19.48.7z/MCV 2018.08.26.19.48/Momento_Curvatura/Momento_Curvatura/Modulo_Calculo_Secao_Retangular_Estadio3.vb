﻿Imports System.Math

Module Modulo_Calculo_Secao_Retangular_Estadio3

    'VARIAVEL
    Public LN_variavel_estadio3 As Double

    'VARIAVEL LN
    Public LN_estadio3 As Double  ' esse é o X da funcao
    Public LN_estadio3_parte1 As Double
    Public LN_estadio3_parte2 As Double
    Public LN_estadio3_parte3 As Double
    Public LN_resultado_parte1_estadio3 As Double
    Public LN_resultado_parte2_estadio3 As Double
    Public LN_resultado_parte3_estadio3 As Double

    'VARIAVEIS CONCRETO
    Public ecm_variavel_estadio3 As Double
    Public etm_variavel_estadio3 As Double
    Public ecm_resultado_parte1_estadio3 As Double
    Public ecm_resultado_parte2_estadio3 As Double
    Public ecm_resultado_parte3_estadio3 As Double
    Public etm_estadio3 As Double
    Public deflexao_estadio3 As Double

    'VARIAVEIS AÇO
    Public es1_estadio3 As Double
    Public es2_estadio3 As Double
    Public es1_variavel_estadio3 As Double
    Public es2_variavel_estadio3 As Double
    Public fy_compressao_estadio3 As Double
    Public fy_tracao_estadio3 As Double
    Public fy As Double



    'VARIAVEIS COEFICIENTES
    Public k1_estadio3 As Double
    Public k1_estadio3_parte1 As Double
    Public k1_estadio3_parte2 As Double

    Public k2_estadio3 As Double
    Public k2_estadio3_parte1 As Double
    Public k2_estadio3_parte2 As Double
    Public k2_estadio3_parte3 As Double
    Public k2_estadio3_parte4 As Double

    Public k3_estadio3 As Double

    Public k4_estadio3 As Double
    Public k4_estadio3_parte1 As Double
    Public k4_estadio3_parte2 As Double
    Public k4_estadio3_parte3 As Double

    'VARIAVEIS MOMENTO
    Public momento_estadio3 As Double
    Public momento_variavel_estadio3 As Double


    ' DEFORMACOES 

    Function Funcao_es1_Estadio3() As Double

        If aco_compressao = 0 Then

            es1_estadio3 = 0

        Else

            es1_estadio3 = (Funcao_LN_Estadio3() - altura_total + altura_util) * ecm_variavel_estadio3 / Funcao_LN_Estadio3()


        End If

        Return es1_estadio3

    End Function


    Function Funcao_es2_Estadio3() As Double

        es2_estadio3 = (altura_util - Funcao_LN_Estadio3()) * ecm_variavel_estadio3 / Funcao_LN_Estadio3()

        Return es2_estadio3

    End Function


    Function Funcao_etm_Estadio3() As Double

        etm_estadio3 = (altura_total - Funcao_LN_Estadio3()) * ecm_variavel_estadio3 / Funcao_LN_Estadio3()

        Return etm_estadio3

    End Function


    ' CALCULO COEFICIENTES K1, K2, K3, K4 

    Function Funcao_k1_Estadio3() As Double

        k1_estadio3_parte1 = (0.5 / Funcao_B_Rec_Estadio1()) * (Math.Log(1 + Funcao_A_Rec_Estadio1() * ecm_variavel_estadio3 + Funcao_B_Rec_Estadio1() * ecm_variavel_estadio3 * ecm_variavel_estadio3))

        k1_estadio3_parte2 = (Funcao_A_Rec_Estadio1() / (Funcao_B_Rec_Estadio1() * Math.Sqrt(Funcao_Q_rec_Estadio1))) * _
        (Math.Atan(Funcao_A_Rec_Estadio1() / Math.Sqrt(Funcao_Q_rec_Estadio1)) - Math.Atan((Funcao_A_Rec_Estadio1() + _
        2 * Funcao_B_Rec_Estadio1() * ecm_variavel_estadio3) / Math.Sqrt(Funcao_Q_rec_Estadio1)))

        k1_estadio3 = (Ec / (fck * ecm_variavel_estadio3)) * (k1_estadio3_parte1 + k1_estadio3_parte2)

        Return k1_estadio3

    End Function


    Function Funcao_k2_Estadio3() As Double

        k2_estadio3_parte1 = (ecm_variavel_estadio3 / Funcao_B_Rec_Estadio1()) - (0.5 * Funcao_A_Rec_Estadio1() / (Funcao_B_Rec_Estadio1() ^ 2)) * _
        Math.Log(1 + Funcao_A_Rec_Estadio1() * ecm_variavel_estadio3 + Funcao_B_Rec_Estadio1() * (ecm_variavel_estadio3 ^ 2)) + _
        ((Funcao_A_Rec_Estadio1() ^ 2) - 2 * Funcao_B_Rec_Estadio1()) * (Math.Atan((2 * Funcao_B_Rec_Estadio1() * ecm_variavel_estadio3 + Funcao_A_Rec_Estadio1()) / _
        Math.Sqrt(Funcao_Q_rec_Estadio1)) - Math.Atan(Funcao_A_Rec_Estadio1() / Math.Sqrt(Funcao_Q_rec_Estadio1))) / _
                ((Funcao_B_Rec_Estadio1() ^ 2) * Math.Sqrt(Funcao_Q_rec_Estadio1))


        k2_estadio3_parte2 = Funcao_k1_Estadio3() * (ecm_variavel_estadio3 ^ 2) * fck / Ec

        k2_estadio3 = 1 - (k2_estadio3_parte1 / k2_estadio3_parte2)

        Return k2_estadio3

    End Function


    Function Funcao_k3_Estadio3() As Double

        k3_estadio3 = ((ftk + Funcao_etp_Rec_Estadio2() * Funcao_Et_Estadio2()) * Funcao_etf_Rec_Estadio2() - 0.5 * Funcao_Et_Estadio2() * ((Funcao_etf_Rec_Estadio2()) ^ 2) - _
        0.5 * ftk * Funcao_etp_Rec_Estadio2() - 0.5 * Funcao_Et_Estadio2() * (Funcao_etp_Rec_Estadio2() ^ 2)) / _
                (ftk * Funcao_etm_Estadio3())

        Return k3_estadio3

    End Function


    Function Funcao_k4_Estadio3() As Double

        k4_estadio3_parte1 = (-(1 / 6) * ftk * Funcao_etp_Rec_Estadio2() * Funcao_etp_Rec_Estadio2()) + _
        (0.5 * ftk + 0.5 * Funcao_Et_Estadio2() * Funcao_etp_Rec_Estadio2()) * (Funcao_etf_Rec_Estadio2() * Funcao_etf_Rec_Estadio2()) - _
                (1 / 3) * Funcao_Et_Estadio2() * (Funcao_etf_Rec_Estadio2() ^ 3) - _
                (1 / 6) * Funcao_Et_Estadio2() * (Funcao_etp_Rec_Estadio2() ^ 3)

        k4_estadio3_parte2 = (Funcao_etm_Estadio3() ^ 2) * Funcao_k3_Estadio3() * ftk

        k4_estadio3 = 1 - (k4_estadio3_parte1 / k4_estadio3_parte2)

        Return k4_estadio3

    End Function



    '   CALCULO LN 


    Function Funcao_LN_Estadio3() As Double

        If fy_tracao_estadio3 < fy And fy_compressao_estadio3 < fy Then

            LN_estadio3_parte1 = Funcao_k1_Estadio3() * fck * largura_maior - _
(largura_maior / ecm_variavel_estadio3) * ((ftk + Funcao_etp_Rec_Estadio2() * Funcao_Et_Estadio2()) * Funcao_etf_Rec_Estadio2() - _
              0.5 * Funcao_Et_Estadio2() * (Funcao_etf_Rec_Estadio2() ^ 2) - _
              0.5 * ftk * Funcao_etp_Rec_Estadio2() - _
              0.5 * Funcao_Et_Estadio2() * (Funcao_etp_Rec_Estadio2() ^ 2))

            LN_estadio3_parte2 = ecm_variavel_estadio3 * Es * aco_compressao + ecm_variavel_estadio3 * Es * aco_tracao

            LN_estadio3_parte3 = -(altura_total - altura_util) * ecm_variavel_estadio3 * Es * aco_compressao - altura_util * ecm_variavel_estadio3 * Es * aco_tracao

            LN_estadio3 = (-LN_estadio3_parte2 + Math.Sqrt((LN_estadio3_parte2 ^ 2) - 4 * LN_estadio3_parte1 * LN_estadio3_parte3)) / (2 * LN_estadio3_parte1)


        ElseIf fy_tracao_estadio3 < fy And fy_compressao_estadio3 > fy Then

            LN_estadio3_parte1 = Funcao_k1_Estadio3() * fck * largura_maior - _
 (largura_maior / ecm_variavel_estadio3) * ((ftk + Funcao_etp_Rec_Estadio2() * Funcao_Et_Estadio2()) * Funcao_etf_Rec_Estadio2() - _
              0.5 * Funcao_Et_Estadio2() * (Funcao_etf_Rec_Estadio2() ^ 2) - _
              0.5 * ftk * Funcao_etp_Rec_Estadio2() - _
              0.5 * Funcao_Et_Estadio2() * (Funcao_etp_Rec_Estadio2() ^ 2))

            LN_estadio3_parte2 = fy * aco_compressao + ecm_variavel_estadio3 * Es * aco_tracao

            LN_estadio3_parte3 = -altura_util * Es * aco_tracao * ecm_variavel_estadio3

            LN_estadio3 = (-LN_estadio3_parte2 + Math.Sqrt((LN_estadio3_parte2 ^ 2) - 4 * LN_estadio3_parte1 * LN_estadio3_parte3)) / (2 * LN_estadio3_parte1)


        ElseIf fy_tracao_estadio3 > fy And fy_compressao_estadio3 < fy Then

            LN_estadio3_parte1 = Funcao_k1_Estadio3() * fck * largura_maior - _
(largura_maior / ecm_variavel_estadio3) * ((ftk + Funcao_etp_Rec_Estadio2() * Funcao_Et_Estadio2()) * Funcao_etf_Rec_Estadio2() - _
0.5 * Funcao_Et_Estadio2() * (Funcao_etf_Rec_Estadio2() ^ 2) - _
             0.5 * ftk * Funcao_etp_Rec_Estadio2() - _
             0.5 * Funcao_Et_Estadio2() * (Funcao_etp_Rec_Estadio2() ^ 2))

            LN_estadio3_parte2 = ecm_variavel_estadio3 * Es * aco_compressao - fy * aco_tracao

            LN_estadio3_parte3 = -(altura_total - altura_util) * ecm_variavel_estadio3 * Es * aco_compressao

            LN_estadio3 = (-LN_estadio3_parte2 + Math.Sqrt((LN_estadio3_parte2 ^ 2) - 4 * LN_estadio3_parte1 * LN_estadio3_parte3)) / (2 * LN_estadio3_parte1)


        ElseIf fy_tracao_estadio3 > fy And fy_compressao_estadio3 > fy Then

            LN_estadio3_parte1 = fy * aco_tracao - fy * aco_compressao

            LN_estadio3_parte2 = Funcao_k1_Estadio3() * fck * largura_maior

            LN_estadio3_parte3 = (largura_maior / ecm_variavel_estadio3) * ((ftk + Funcao_etp_Rec_Estadio2() * Funcao_Et_Estadio2()) * Funcao_etf_Rec_Estadio2() - _
            0.5 * Funcao_Et_Estadio2() * Funcao_etf_Rec_Estadio2() * Funcao_etf_Rec_Estadio2() - _
                        0.5 * ftk * Funcao_etp_Rec_Estadio2() - _
            0.5 * Funcao_Et_Estadio2() * Funcao_etp_Rec_Estadio2() * Funcao_etp_Rec_Estadio2())

            LN_estadio3 = LN_estadio3_parte1 / (LN_estadio3_parte2 - LN_estadio3_parte3)

        End If

        Return LN_estadio3

    End Function

    ' CALCULO MOMENTO ESTADIO 3 

    Function Funcao_Momento_Estadio3() As Double

        'O momento depende da LN, K1, K2, K3, K4

        If es1_estadio3 * Es > fy And es2_estadio3 * Es > fy Then

            momento_estadio3 = Funcao_k1_Estadio3() * fck * largura_maior * 10 * Funcao_LN_Estadio3() * 10 * (altura_total * 0.5 * 10 - Funcao_k2_Estadio3() * Funcao_LN_Estadio3() * 10) +
            fy * aco_compressao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + fy * aco_tracao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + Funcao_k3_Estadio3() * ftk * largura_maior * 10 * (altura_total * 10 - Funcao_LN_Estadio3() * 10) * _
            (altura_total * 0.5 * 10 - Funcao_k4_Estadio3() * (altura_total * 10 - Funcao_LN_Estadio3() * 10))

        ElseIf es1_estadio3 * Es > fy And es2_estadio3 * Es < fy Then

            momento_estadio3 = Funcao_k1_Estadio3() * fck * largura_maior * 10 * Funcao_LN_Estadio3() * 10 * (altura_total * 0.5 * 10 - Funcao_k2_Estadio3() * Funcao_LN_Estadio3() * 10) +
            fy * aco_compressao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + Es * Funcao_es2_Estadio3() * aco_tracao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + _
            Funcao_k3_Estadio3() * ftk * largura_maior * 10 * (altura_total * 10 - Funcao_LN_Estadio3() * 10) * _
            (altura_total * 0.5 * 10 - Funcao_k4_Estadio3() * (altura_total * 10 - Funcao_LN_Estadio3() * 10))

        ElseIf es1_estadio3 * Es < fy And es2_estadio3 * Es > fy Then

            momento_estadio3 = Funcao_k1_Estadio3() * fck * largura_maior * 10 * Funcao_LN_Estadio3() * 10 * (altura_total * 0.5 * 10 - Funcao_k2_Estadio3() * Funcao_LN_Estadio3() * 10) +
            Es * Funcao_es1_Estadio3() * aco_compressao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + _
            fy * aco_tracao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + Funcao_k3_Estadio3() * ftk * largura_maior * 10 * (altura_total * 10 - Funcao_LN_Estadio3() * 10) * _
            (altura_total * 0.5 * 10 - Funcao_k4_Estadio3() * (altura_total * 10 - Funcao_LN_Estadio3() * 10))

        ElseIf es1_estadio3 * Es < fy And es2_estadio3 * Es < fy Then

            momento_estadio3 = Funcao_k1_Estadio3() * fck * largura_maior * 10 * Funcao_LN_Estadio3() * 10 * (altura_total * 0.5 * 10 - Funcao_k2_Estadio3() * Funcao_LN_Estadio3() * 10) +
            Es * Funcao_es1_Estadio3() * aco_compressao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + _
            Es * Funcao_es2_Estadio3() * aco_tracao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + _
            Funcao_k3_Estadio3() * ftk * largura_maior * 10 * (altura_total * 10 - Funcao_LN_Estadio3() * 10) * _
            (altura_total * 0.5 * 10 - Funcao_k4_Estadio3() * (altura_total * 10 - Funcao_LN_Estadio3() * 10))

        End If

        Return momento_estadio3 * 0.000001

    End Function

    ' FIM CALCULOS SECAO ESTADIO 3 ----------------------------------------------------------------------------------------------------

End Module
