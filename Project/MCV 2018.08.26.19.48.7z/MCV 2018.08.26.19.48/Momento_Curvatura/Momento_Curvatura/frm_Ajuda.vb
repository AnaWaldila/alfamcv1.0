﻿' AJUDA

Public Class frm_Ajuda

    Private Sub MenuPrincipalToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MenuPrincipalToolStripMenuItem.Click

        frm_Menu_Principal.Show()
        Me.Close()

    End Sub

    Private Sub CálculoMomentoXDeformaçaoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CálculoMomentoXDeformaçaoToolStripMenuItem.Click

        frm_Calcula_Secao.Show()
        Me.Close()

    End Sub

End Class