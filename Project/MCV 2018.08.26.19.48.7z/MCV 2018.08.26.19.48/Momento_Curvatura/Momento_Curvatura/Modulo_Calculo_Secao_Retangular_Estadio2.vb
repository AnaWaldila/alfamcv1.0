﻿Imports System.Math

Module Modulo_Calculo_Secao_Retangular_Estadio2


    'VARIAVEL LN
    Public LN_estadio2 As Double
    Public LN_estadio2_parte1 As Double
    Public LN_estadio2_parte2 As Double
    Public LN_estadio2_parte3 As Double
    Public LN_resultado_parte1_estadio2 As Double
    Public LN_resultado_parte2_estadio2 As Double
    Public LN_resultado_parte3_estadio2 As Double
    Public LN As Double ' Essa é a variavel 

    Public i As Double

    'VARIAVEIS AÇO
    Public es1_estadio2 As Double
    Public es2_estadio2 As Double
    Public es1_variavel_estadio2 As Double
    Public es2_variavel_estadio2 As Double
    Public fy_compressao_estadio2 As Double
    Public fy_tracao_estadio2 As Double

    'VARIAVEIS CONCRETO
    Public Et As Double
    Public ecm_variavel_estadio2 As Double
    Public ecm_estadio2 As Double
    Public ecm_final_estadio2 As Double
    Public ecm_resultado_parte1_estadio2 As Double
    Public ecm_resultado_parte2_estadio2 As Double
    Public ecm_resultado_parte3_estadio2 As Double
    Public etp As Double
    Public etf As Double
    Public etm_estadio2 As Double
    Public etm_variavel_estadio2 As Double
    Public deflexao_estadio2 As Double
    Public deflexao_variavel_estadio2 As Double

    'VARIAVEIS COEFICIENTES
    Public k1_estadio2 As Double
    Public k1_estadio2_parte1 As Double
    Public k1_estadio2_parte2 As Double

    Public k2_estadio2 As Double
    Public k2_estadio2_parte1 As Double
    Public k2_estadio2_parte2 As Double
    Public k2_estadio2_parte3 As Double
    Public k2_estadio2_parte4 As Double

    Public k3_estadio2 As Double

    Public k4_estadio2 As Double
    Public k4_estadio2_parte1 As Double
    Public k4_estadio2_parte2 As Double

    'VARIAVEL MOMENTO 
    Public momento_estadio2 As Double
    Public momento_variavel_estadio2 As Double

    ' CALCULO MODULO 

    Function Funcao_Et_Estadio2() As Double

        Et = (70 * Ec * (1000000 / 6895) / (57 + ftk * (1000000 / 6895))) * (6895 / 1000000)

        Return Et

    End Function


    ' CALCULO DEFORMACOES 

    Function Funcao_etp_Rec_Estadio2() As Double

        etp = ftk / Ec

        Return etp

    End Function


    Function Funcao_etf_Rec_Estadio2() As Double

        etf = (ftk / Funcao_Et_Estadio2()) + Funcao_etp_Rec_Estadio2()

        Return etf

    End Function


    Function Funcao_ecm_Rec_Estadio2() As Double

        ecm_estadio2 = Funcao_LN_Estadio2() * Funcao_etp_Rec_Estadio2() / (altura_total - Funcao_LN_Estadio2())

        Return ecm_estadio2

    End Function


    Function Funcao_etm_Rec_Estadio2() As Double

        etm_estadio2 = (altura_total - Funcao_LN_Estadio2()) * ecm_variavel_estadio2 / Funcao_LN_Estadio2()

        Return etm_estadio2

    End Function


    Function Funcao_ecm_Final_Rec_Estadio2() As Double

        ecm_final_estadio2 = Funcao_LN_Estadio2() * Funcao_etf_Rec_Estadio2() / (altura_total - Funcao_LN_Estadio2())

        Return ecm_final_estadio2

    End Function


    Function Funcao_es1_Estadio2() As Double

        If aco_compressao = 0 Then

            es1_estadio2 = 0

        Else

            es1_estadio2 = (Funcao_LN_Estadio2() - altura_total + altura_util) * ecm_variavel_estadio2 / Funcao_LN_Estadio2()

        End If

        Return es1_estadio2

    End Function


    Function Funcao_es2_Estadio2() As Double

        es2_estadio2 = (altura_util - Funcao_LN_Estadio2()) * ecm_variavel_estadio2 / Funcao_LN_Estadio2()

        Return es2_estadio2

    End Function

    ' CALCULO COEFICIENTES K1, K2, K3, K4 

    Function Funcao_k1_Estadio2() As Double

        k1_estadio2_parte1 = (0.5 / Funcao_B_Rec_Estadio1()) * (Math.Log(1 + Funcao_A_Rec_Estadio1() * ecm_variavel_estadio2 + _
                Funcao_B_Rec_Estadio1() * ecm_variavel_estadio2 * ecm_variavel_estadio2))

        k1_estadio2_parte2 = (Funcao_A_Rec_Estadio1() / (Funcao_B_Rec_Estadio1() * Math.Sqrt(Funcao_Q_rec_Estadio1))) * _
        (Math.Atan(Funcao_A_Rec_Estadio1() / Math.Sqrt(Funcao_Q_rec_Estadio1)) - Math.Atan((Funcao_A_Rec_Estadio1() + 2 * Funcao_B_Rec_Estadio1() * ecm_variavel_estadio2) / _
                Math.Sqrt(Funcao_Q_rec_Estadio1)))

        k1_estadio2 = (Ec / (fck * ecm_variavel_estadio2)) * (k1_estadio2_parte1 + k1_estadio2_parte2)

        Return k1_estadio2

    End Function


    Function Funcao_k2_Estadio2() As Double

        k2_estadio2_parte1 = (ecm_variavel_estadio2 / Funcao_B_Rec_Estadio1()) - (0.5 * Funcao_A_Rec_Estadio1() / (Funcao_B_Rec_Estadio1() ^ 2)) * _
        Math.Log(1 + Funcao_A_Rec_Estadio1() * ecm_variavel_estadio2 + Funcao_B_Rec_Estadio1() * (ecm_variavel_estadio2 ^ 2)) + _
        (Funcao_A_Rec_Estadio1() ^ 2 - 2 * Funcao_B_Rec_Estadio1()) * (Math.Atan((2 * Funcao_B_Rec_Estadio1() * ecm_variavel_estadio2 + Funcao_A_Rec_Estadio1()) / _
        Math.Sqrt(Funcao_Q_rec_Estadio1)) - Math.Atan(Funcao_A_Rec_Estadio1() / Math.Sqrt(Funcao_Q_rec_Estadio1))) / _
                       (Funcao_B_Rec_Estadio1() ^ 2 * Math.Sqrt(Funcao_Q_rec_Estadio1))

        k2_estadio2_parte2 = Funcao_k1_Estadio2() * (ecm_variavel_estadio2 ^ 2) * fck / Ec

        k2_estadio2 = 1 - (k2_estadio2_parte1 / k2_estadio2_parte2)

        Return k2_estadio2

    End Function


    Function Funcao_k3_Estadio2() As Double

        k3_estadio2 = ((ftk + Funcao_etp_Rec_Estadio2() * Funcao_Et_Estadio2()) * (altura_total - Funcao_LN_Estadio2()) * ecm_variavel_estadio2 / (Funcao_LN_Estadio2()) - _
        0.5 * Funcao_Et_Estadio2() * (((altura_total - Funcao_LN_Estadio2()) * ecm_variavel_estadio2 / (Funcao_LN_Estadio2())) ^ 2) - _
        0.5 * ftk * Funcao_etp_Rec_Estadio2() - 0.5 * Funcao_Et_Estadio2() * (Funcao_etp_Rec_Estadio2() ^ 2)) / _
        (ftk * (altura_total - Funcao_LN_Estadio2()) * ecm_variavel_estadio2 / (Funcao_LN_Estadio2()))

        Return k3_estadio2

    End Function


    Function Funcao_k4_Estadio2() As Double

        k4_estadio2_parte1 = -(1 / 6) * ftk * (Funcao_etp_Rec_Estadio2() ^ 2) + (0.5 * ftk + 0.5 * Funcao_Et_Estadio2() * Funcao_etp_Rec_Estadio2()) _
        * (((altura_total - Funcao_LN_Estadio2()) * ecm_variavel_estadio2 / (Funcao_LN_Estadio2())) ^ 2) - _
        (1 / 3) * Funcao_Et_Estadio2() * (((altura_total - Funcao_LN_Estadio2()) * ecm_variavel_estadio2 / (Funcao_LN_Estadio2())) ^ 3) - _
                (1 / 6) * Funcao_Et_Estadio2() * ((Funcao_etp_Rec_Estadio2()) ^ 3)

        k4_estadio2_parte2 = Funcao_k3_Estadio2() * _
(((altura_total - Funcao_LN_Estadio2()) * ecm_variavel_estadio2 / (Funcao_LN_Estadio2())) ^ 2) * ftk

        k4_estadio2 = 1 - (k4_estadio2_parte1 / k4_estadio2_parte2)

        Return k4_estadio2

    End Function


    ' CALCULO LN 

    Function Funcao_LN_Estadio2() As Double

        LN_estadio2_parte1 = (ecm_variavel_estadio2 * Es * (aco_compressao + aco_tracao) - _
        largura_maior * altura_total * (ftk + Funcao_etp_Rec_Estadio2() * Funcao_Et_Estadio2()) - _
        Funcao_Et_Estadio2() * largura_maior * altura_total * ecm_variavel_estadio2)

        LN_estadio2_parte2 = (ecm_variavel_estadio2 * Es * ((altura_total - altura_util) * aco_compressao + altura_util * aco_tracao) _
        - 0.5 * altura_total * altura_total * Funcao_Et_Estadio2() * largura_maior * ecm_variavel_estadio2)

        LN_estadio2_parte3 = ((Funcao_k1_Estadio2() * fck * largura_maior + _
largura_maior * (ftk + Funcao_etp_Rec_Estadio2() * Funcao_Et_Estadio2()) + 0.5 * Funcao_Et_Estadio2() * largura_maior * ecm_variavel_estadio2 - _
       largura_maior * (-0.5 * ftk * Funcao_etp_Rec_Estadio2() - _
       0.5 * Funcao_Et_Estadio2() * Funcao_etp_Rec_Estadio2() * _
       Funcao_etp_Rec_Estadio2()) / ecm_variavel_estadio2))

        LN_estadio2 = (-LN_estadio2_parte1 + _
Math.Sqrt(LN_estadio2_parte1 * LN_estadio2_parte1 + 4 * LN_estadio2_parte2 * LN_estadio2_parte3)) / _
       (2 * LN_estadio2_parte3)

        Return LN_estadio2

    End Function

    ' CALCULO MOMENTO ESTADIO 2 

    Function Funcao_Momento_Estadio2() As Double

        'O momento depende da LN, K1, K2, K3, K4

        momento_estadio2 = Funcao_k1_Estadio2() * fck * largura_maior * 10 * Funcao_LN_Estadio2() * 10 * (altura_total * 0.5 * 10 - Funcao_k2_Estadio2() * Funcao_LN_Estadio2() * 10) +
        Funcao_es1_Estadio2() * Es * aco_compressao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + _
        Funcao_es2_Estadio2() * Es * aco_tracao * 100 * (altura_util * 10 - 0.5 * altura_total * 10) + _
        Funcao_k3_Estadio2() * ftk * largura_maior * 10 * (altura_total * 10 - Funcao_LN_Estadio2() * 10) * _
        (altura_total * 0.5 * 10 - Funcao_k4_Estadio2() * (altura_total * 10 - Funcao_LN_Estadio2() * 10))

        Return momento_estadio2 * 0.000001

    End Function

    ' FIM CALCULOS SECAO ESTADIO 2 

End Module
