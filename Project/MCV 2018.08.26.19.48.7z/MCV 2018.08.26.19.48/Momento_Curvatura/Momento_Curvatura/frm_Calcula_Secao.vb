﻿' CALCULA SECAO

Public Class frm_Calcula_Secao

    ' ESTADIO 1
    Public deflexao_estadio1 As Double


    ' ESTADIO 2
    Public eixo_ecm_estadio2(i) As Double
    Public eixo_etm_estadio2(i) As Double
    Public eixo_momento_estadio2(i) As Double
    Public eixo_aco_compressao_estadio2(i) As Double
    Public eixo_aco_tracao_estadio2(i) As Double
    Public eixo_linha_neutra_estadio2(i) As Double
    Public eixo_deflexao_estadio2(i) As Double

    ' ESTADIO 3
    Public eixo_ecm_estadio3(j) As Double
    Public eixo_etm_estadio3(j) As Double
    Public eixo_momento_estadio3(j) As Double
    Public eixo_aco_compressao_estadio3(j) As Double
    Public eixo_aco_tracao_estadio3(j) As Double
    Public eixo_linha_neutra_estadio3(j) As Double
    Public numero_linhas_estadio3 As Double
    Public eixo_deflexao_estadio3(j) As Double

    ' CONTAGEM DE LINHA
    Public i_final As Int64

    Public i As Int64

    Public j As Int64

    Public x As Int64


    Private Sub btn_Calcular_Click_1(sender As Object, e As EventArgs) Handles btn_Calcular.Click

        If (txt_altura.Text = "" Or txt_altura_util.Text = "" Or txt_largura.Text = "" Or txt_fck.Text = "" Or _
                txt_aco_compressao.Text = "" Or txt_aco_tracao.Text = "" Or _
        txt_modulo_aco.Text = "" Or txt_ftk.Text = "" Or txt_modulo_concreto.Text = "" Or txt_fy_aco.Text = "" Or _
                   txt_comprimento_vao.Text = "") Then

            MessageBox.Show("Preencha todos os campos.", "Campos Vazios", MessageBoxButtons.OK, MessageBoxIcon.Information)

            If txt_altura.Text = "" Then

                txt_altura.Focus()

            ElseIf txt_altura_util.Text = "" Then

                txt_altura_util.Focus()

            ElseIf txt_largura.Text = "" Then

                txt_largura.Focus()

            ElseIf txt_fck.Text = "" Then

                txt_fck.Focus()

            ElseIf txt_aco_compressao.Text = "" Then

                txt_aco_compressao.Focus()

            ElseIf txt_aco_tracao.Text = "" Then

                txt_aco_tracao.Focus()

            ElseIf txt_modulo_aco.Text = "" Then

                txt_modulo_aco.Focus()

            ElseIf txt_ftk.Text = "" Then

                txt_ftk.Focus()

            ElseIf txt_modulo_concreto.Text = "" Then

                txt_modulo_concreto.Focus()

            ElseIf txt_fy_aco.Text = "" Then

                txt_fy_aco.Focus()

            ElseIf txt_comprimento_vao.Text = "" Then

                txt_comprimento_vao.Focus()

            End If

        End If

        ' Verifica se todos os campos estao preenchidos e recebe os valores de calculo

        If (txt_altura.Text <> "" And txt_altura_util.Text <> "" And txt_largura.Text <> "" And txt_fck.Text <> "" And _
                txt_aco_compressao.Text <> "" And txt_aco_tracao.Text <> "" And _
        txt_modulo_aco.Text <> "" And txt_ftk.Text <> "" And txt_modulo_concreto.Text <> "" And txt_fy_aco.Text <> "" And _
               txt_comprimento_vao.Text <> "") Then

            Modulo_Calculo_Secao_Retangular_Estadio1.comprimento_vao = txt_comprimento_vao.Text

            Modulo_Calculo_Secao_Retangular_Estadio1.altura_total = txt_altura.Text

            Modulo_Calculo_Secao_Retangular_Estadio1.altura_util = txt_altura_util.Text


            Modulo_Calculo_Secao_Retangular_Estadio1.largura_maior = txt_largura.Text

            Modulo_Calculo_Secao_Retangular_Estadio1.L = txt_comprimento_vao.Text

            Modulo_Calculo_Secao_Retangular_Estadio1.fck = txt_fck.Text
            Modulo_Calculo_Secao_Retangular_Estadio1.ftk = txt_ftk.Text

            Modulo_Calculo_Secao_Retangular_Estadio1.Ec = txt_modulo_concreto.Text

            Modulo_Calculo_Secao_Retangular_Estadio1.aco_compressao = txt_aco_compressao.Text

            Modulo_Calculo_Secao_Retangular_Estadio1.aco_tracao = txt_aco_tracao.Text

            Modulo_Calculo_Secao_Retangular_Estadio1.Es = txt_modulo_aco.Text

            Modulo_Calculo_Secao_Retangular_Estadio3.fy = txt_fy_aco.Text

            My.Forms.frm_Resultado.txt_resultado_LN.Text = Format(Funcao_LN_Estadio1(), "####.00000")

            My.Forms.frm_Resultado.txt_resultado_deformacao_tracao_concreto.Text = Format(Funcao_etp_Rec_Estadio1(), "####.0000000000")

            My.Forms.frm_Resultado.txt_resultado_compressao_concreto.Text = Format(Funcao_ecm_Rec_Estadio1(), "####.00000")

            My.Forms.frm_Resultado.txt_resultado_compressao_maxima_concreto.Text = Format(Funcao_ecp_Rec_Estadio1(), "####.0000000000")

            My.Forms.frm_Resultado.txt_resultado_Aco_compressao.Text = Format(Funcao_es1_Rec_Estadio1(), "####.0000000000")

            My.Forms.frm_Resultado.txt_resultado_aco_tracao.Text = Format(Funcao_es2_Rec_Estadio1(), "####.0000000000")

            My.Forms.frm_Resultado.txt_resultado_momento_fissuracao.Text = Format(Funcao_Momento_Rec_Estadio1(), "####.00000")

            ' Inicio ao comando For. Para isso, precisamos iniciar o valor de deformacao_compressao_variavel_concreto_Estadio2. Ele inicia o com o valor de deformacao
            ' de compressao final encontrado no estadio 1

            For x As Int64 = 1 To 2 Step 1

                'ESTADIO 1

                If My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count = 0 Then

                    ' add primeira linha 

                    My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Add("0", "Regime Linear (Estadio 1)", _
                                                                       Format(Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_LN_Estadio1(), "####.00000"), _
                                                                       Format(Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1(), "####.0000000000"), _
                                                                       Format(Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_etp_Rec_Estadio1(), "####.0000000000"), _
                                                                       Format(Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_es1_Rec_Estadio1(), "####.0000000000"), _
                                                                       Format(Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_es2_Rec_Estadio1, "####.0000000000"), _
                                                                       Format(Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1(), "####.00000"), _
                                                                       Format(Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Deflexao_Estadio1(), "####.0000000000"))

                    'ESTADIO 2

                Else

                    ecm_variavel_estadio2 = Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1()

                    For i As Int64 = 1 To 100000 Step 1   ' Nao se sabe quantos passos terao, apenas a extrapolei para 1000 'for' 

                        'Cálculos

                        fy_compressao_estadio2 = Modulo_Calculo_Secao_Retangular_Estadio2.Funcao_es1_Estadio2() * Es

                        fy_tracao_estadio2 = Modulo_Calculo_Secao_Retangular_Estadio2.Funcao_es2_Estadio2() * Es

                        ecm_variavel_estadio2 = ecm_variavel_estadio2 * 1.01 ' ACRESCENTAR 1% EM CIMA DO ENCREMENTO FEITO

                        LN = Funcao_LN_Estadio2()

                        momento_variavel_estadio2 = Modulo_Calculo_Secao_Retangular_Estadio2.Funcao_Momento_Estadio2()

                        etm_variavel_estadio2 = Modulo_Calculo_Secao_Retangular_Estadio2.Funcao_etm_Rec_Estadio2()

                        es1_variavel_estadio2 = Modulo_Calculo_Secao_Retangular_Estadio2.Funcao_es1_Estadio2()

                        es2_variavel_estadio2 = Modulo_Calculo_Secao_Retangular_Estadio2.Funcao_es2_Estadio2()

                        'VERIFICACAO DO ACO

                        If fy_compressao_estadio2 > txt_fy_aco.Text Then

                            Exit For

                        Else

                            es1_variavel_estadio2 = Modulo_Calculo_Secao_Retangular_Estadio2.Funcao_es1_Estadio2()

                        End If

                        If fy_tracao_estadio2 > txt_fy_aco.Text Then

                            Exit For

                        Else

                            es2_variavel_estadio2 = Modulo_Calculo_Secao_Retangular_Estadio2.Funcao_es2_Estadio2()

                        End If

                        'VARIFICACAO DO CONCRETO

                        If (etm_variavel_estadio2 <= Modulo_Calculo_Secao_Retangular_Estadio2.Funcao_etf_Rec_Estadio2) Then


                            ' PRIMEIRA VERIFICAÇÃO QUANTO AO MOMENTO: 3Mi/4 MENOR QUE O MOMENTO DE FISSURAÇÃO

                            If 3 * momento_variavel_estadio2 / 4 <= Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 Then


                                deflexao_estadio2 = ((comprimento_vao ^ 2) / 48) * ((3 * momento_variavel_estadio2 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1 / (Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_LN_Estadio1)) + (ecm_variavel_estadio2 / LN))

                                My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Add(i, "Regime Nao Linear (Estadio 2)-1", _
                                                                               Format(LN, "####.00000"), _
                                                                               Format(ecm_variavel_estadio2, "####.0000000000"), _
                                                                               Format(es1_variavel_estadio2, "####.0000000000"), _
                                                                               Format(es2_variavel_estadio2, "####.0000000000"), _
                                                                               Format(momento_variavel_estadio2, "####.00000"), _
                                                                               Format(deflexao_estadio2, "####.0000000000"))

                                'SEGUNDA VERIFICAÇÃO QUANTO AO MOMENTO: 3Mi/4 MAIOR QUE O MEOMENTO DE FISSURACAO E Mi/2 MENOR 


                            ElseIf 3 * momento_variavel_estadio2 / 4 > Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 And _
                            momento_variavel_estadio2 / 2 < Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 Then

                                My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Add(i, "Regime Nao Linear (Estadio 2)-2", _
                                                                               Format(LN, "####.00000"), _
                                                                               Format(ecm_variavel_estadio2, "####.0000000000"), _
                                                                               Format(es1_variavel_estadio2, "####.0000000000"), _
                                                                               Format(es2_variavel_estadio2, "####.0000000000"), _
                                                                               Format(momento_variavel_estadio2, "####.00000"), _
                                                                               "0")

                                For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                                    If My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * 3 * momento_variavel_estadio2 / 4 _
                                    And My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (3 * momento_variavel_estadio2 / 4) Then  'verifica a condição do valor do momento na coluna momento

                                        ecm_resultado_parte1_estadio2 = My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                        LN_resultado_parte1_estadio2 = My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()


                                        deflexao_estadio2 = ((comprimento_vao ^ 2) / 48) * _
            ((3 * momento_variavel_estadio2 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1 / _
            (4 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_LN_Estadio1)) + _
            (3 * ecm_resultado_parte1_estadio2 / LN_resultado_parte1_estadio2) + _
                                       (ecm_variavel_estadio2 / LN))

                                        'ADD
                                        My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Item(My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1).Cells(7).Value = Format(deflexao_estadio2, "####.0000000000")

                                        Exit For

                                    End If

                                Next

                                ' TERCEIRA VERIFICAÇÃO QUANTO AO MOMENTO: Mi/2 MAIOR QUE O MOMENTO DE FISSURACAO E Mi/4 MENOR


                            ElseIf momento_variavel_estadio2 / 2 > Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 And _
                            momento_variavel_estadio2 / 4 < Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 Then
                                My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Add(i, "Regime Nao Linear (Estadio 2)-3", _
                                                                               Format(LN, "####.00000"), _
                                                                               Format(ecm_variavel_estadio2, "####.0000000000"), _
                                                                               Format(es1_variavel_estadio2, "####.0000000000"), _
                                                                               Format(es2_variavel_estadio2, "####.0000000000"), _
                                                                               Format(momento_variavel_estadio2, "####.00000"), _
                                                                               "0")

                                For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                                    If My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * 3 * momento_variavel_estadio2 / 4 _
                                    And My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (3 * momento_variavel_estadio2 / 4) Then

                                        ecm_resultado_parte1_estadio2 = My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                        LN_resultado_parte1_estadio2 = My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()

                                        Exit For
                                    End If
                                Next

                                For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                                    If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * momento_variavel_estadio2 / 2 _
                                    And frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (momento_variavel_estadio2 / 2) Then

                                        ecm_resultado_parte2_estadio2 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                        LN_resultado_parte2_estadio2 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()

                                        Exit For

                                    End If

                                Next



                                deflexao_estadio2 = ((comprimento_vao ^ 2) / 48) * ((3 * momento_variavel_estadio2 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1 / _
                                (4 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_LN_Estadio1)) + _
                                (3 * ecm_resultado_parte1_estadio2 / LN_resultado_parte1_estadio2) + _
                                                                (ecm_variavel_estadio2 / LN))

                                'ADD
                                My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Item(My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1).Cells(7).Value = Format(deflexao_estadio2, "####.0000000000")



                                'QUARTA VERIFICAÇÃO QUANTO AO MOMENTO: Mi/4 MAIOR QUE O MOMENTO DE FISSURACAO

                            ElseIf momento_variavel_estadio2 / 4 > Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 Then


                                My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Add(i, "Regime Nao Linear (Estadio 2)-4", _
                                                                               Format(LN, "####.00000"), _
                                                                               Format(ecm_variavel_estadio2, "####.0000000000"), _
                                                                               Format(es1_variavel_estadio2, "####.0000000000"), _
                                                                               Format(es2_variavel_estadio2, "####.0000000000"), _
                                                                               Format(momento_variavel_estadio2, "####.00000"), _
                                                                               "0")


                                For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                                    If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * 3 * momento_variavel_estadio2 / 4 _
                                    And frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (3 * momento_variavel_estadio2 / 4) Then  'verifica a condição do valor do momento na coluna momento

                                        ecm_resultado_parte1_estadio2 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                        LN_resultado_parte1_estadio2 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()

                                        Exit For

                                    End If

                                Next

                                For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                                    If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * momento_variavel_estadio2 / 2 _
                                    And frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (momento_variavel_estadio2 / 2) Then

                                        ecm_resultado_parte2_estadio2 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                        LN_resultado_parte2_estadio2 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()

                                        Exit For

                                    End If

                                Next

                                For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                                    If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * momento_variavel_estadio2 / 4 _
                                    And frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (momento_variavel_estadio2 / 4) Then

                                        ecm_resultado_parte3_estadio2 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                        LN_resultado_parte3_estadio2 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()

                                        Exit For

                                    End If

                                Next


                                deflexao_estadio2 = ((comprimento_vao ^ 2) / 48) * _
                             ((ecm_resultado_parte3_estadio2 / LN_resultado_parte3_estadio2) + _
     (ecm_resultado_parte2_estadio2 / LN_resultado_parte2_estadio2) + _
     (3 * ecm_resultado_parte1_estadio2 / LN_resultado_parte1_estadio2) + _
                                (ecm_variavel_estadio2 / LN))

                                'ADD
                                My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Item(My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1).Cells(7).Value = Format(deflexao_estadio2, "####.0000000000")


                            End If

                            ecm_variavel_estadio3 = ecm_variavel_estadio2

                            es1_variavel_estadio3 = es1_variavel_estadio2

                            es2_variavel_estadio3 = es2_variavel_estadio3

                            i_final = i

                        Else

                            Exit For

                        End If

                    Next i

                End If

            Next x

            ' PRESERVANDO OS VALORES

            ecm_variavel_estadio3 = ecm_variavel_estadio2

            es1_variavel_estadio3 = es1_variavel_estadio2

            es2_variavel_estadio3 = es2_variavel_estadio3

            momento_variavel_estadio3 = momento_variavel_estadio2


            ' ESTADIO 3

            'INICIANDO A CONTAGEM

            For j As Int64 = i_final + 1 To 100000 Step 1

                ecm_variavel_estadio3 = ecm_variavel_estadio3

                etm_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_etm_Estadio3() ' Calcula a variacao da deformaçao de tracao do concreto 

                fy_compressao_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es1_Estadio3() * Es ' Calcula a variacao da tensao no aco de compressao

                fy_tracao_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es2_Estadio3() * Es ' Calcula a variacao da tensao no aco de tracao

                es1_variavel_estadio3 = Funcao_es1_Estadio3() ' Calcula a variacao na deformacao do aco de compressao

                es2_variavel_estadio3 = Funcao_es2_Estadio3() ' Calcula a variacao na deformacao do aco de tracao

                momento_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_Momento_Estadio3()

                ' VERIFICACAO DO ACO

                If fy_tracao_estadio3 > txt_fy_aco.Text And fy_compressao_estadio3 > txt_fy_aco.Text Then  ' ACO TRAÇÃO E COMPRESSAO ESCOAM

                    fy_tracao_estadio3 = fy

                    es2_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es2_Estadio3()

                    fy_compressao_estadio3 = fy

                    es1_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es1_Estadio3()

                    LN_variavel_estadio3 = Funcao_LN_Estadio3()

                    momento_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_Momento_Estadio3()

                ElseIf fy_tracao_estadio3 < txt_fy_aco.Text And fy_compressao_estadio3 > txt_fy_aco.Text Then  ' ACO TRACAO NÃO ESCOA E COMPRESSAO ESCOA

                    es2_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es2_Estadio3()

                    fy_tracao_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es2_Estadio3() * Es

                    fy_compressao_estadio3 = fy

                    es1_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es1_Estadio3()

                    LN_variavel_estadio3 = Funcao_LN_Estadio3()

                    momento_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_Momento_Estadio3()

                ElseIf fy_tracao_estadio3 > txt_fy_aco.Text And fy_compressao_estadio3 < txt_fy_aco.Text Then  ' ACP TRACAO ESCOA E COMPRESSAO NAO ESCOA

                    fy_tracao_estadio3 = fy

                    es2_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es2_Estadio3()

                    es1_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es1_Estadio3()

                    fy_compressao_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es1_Estadio3 * Es

                    LN_variavel_estadio3 = Funcao_LN_Estadio3()

                    momento_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_Momento_Estadio3()

                ElseIf fy_tracao_estadio3 < txt_fy_aco.Text And fy_compressao_estadio3 < txt_fy_aco.Text Then  ' ACO TRACAO E COMPRESSAO NAO ESCOAM

                    es2_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es2_Estadio3()

                    fy_tracao_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es2_Estadio3() * Es

                    es1_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es1_Estadio3()

                    fy_compressao_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_es1_Estadio3 * Es

                    LN_variavel_estadio3 = Funcao_LN_Estadio3()

                    momento_variavel_estadio3 = Modulo_Calculo_Secao_Retangular_Estadio3.Funcao_Momento_Estadio3()

                End If

                ' VERIFICACAO DO CONCRETO

                If ecm_variavel_estadio3 <= 3.5 * 0.001 Then

                    '   PRIMEIRA VERIFICACAO

                    If 3 * momento_variavel_estadio3 / 4 <= Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 Then


                        deflexao_estadio3 = ((comprimento_vao ^ 2) / 48) * ( _
(3 * momento_variavel_estadio3 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1 / (Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_LN_Estadio1)) + (ecm_variavel_estadio3 / LN_estadio3))


                        My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Add(j, "Regime Nao Linear (Estadio 3)-1", _
                                                                                Format(LN_estadio3, "####.00000"), _
                                                                                Format(ecm_variavel_estadio3, "####.0000000000"), _
                                                                                Format(es1_variavel_estadio3, "####.0000000000"), _
                                                                                Format(es2_variavel_estadio3, "####.0000000000"), _
                                                                                Format(momento_variavel_estadio3, "####.00000"), _
                                                                                Format(deflexao_estadio3, "####.00000000000"))

                        '   SEGUNDA VERIFICACAO

                    ElseIf 3 * momento_variavel_estadio3 / 4 > Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 And _
                    momento_variavel_estadio3 / 2 < Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 Then

                        My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Add(j, "Regime Nao Linear (Estadio 3) - 2", _
                                                                               Format(LN_estadio3, "####.00000"), _
                                                                               Format(ecm_variavel_estadio3, "####.0000000000"), _
                                                                               Format(es1_variavel_estadio3, "####.0000000000"), _
                                                                               Format(es2_variavel_estadio3, "####.0000000000"), _
                                                                               Format(momento_variavel_estadio3, "####.00000"), _
                                                                               "0")

                        For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                            If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * (3 * momento_variavel_estadio3 / 4) And frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (3 * momento_variavel_estadio3 / 4) Then

                                ecm_resultado_parte1_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                LN_resultado_parte1_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()


                                deflexao_estadio3 = ((comprimento_vao ^ 2) / 48) * ((3 * momento_variavel_estadio3 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1 / _
                                (4 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_LN_Estadio1)) + _
                                (3 * ecm_resultado_parte1_estadio3 / LN_resultado_parte1_estadio3) + _
                                                               (ecm_variavel_estadio3 / LN_estadio3))

                                'ADD
                                My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Item(My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1).Cells(7).Value = Format(deflexao_estadio3, "####.0000000000")

                                Exit For

                            End If

                        Next


                        '   TERCEIRA VERIFICACAO

                    ElseIf momento_variavel_estadio3 / 2 > Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 And _
                    momento_variavel_estadio3 / 4 < Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 Then

                        My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Add(j, "Regime Nao Linear (Estadio 3) - 2", _
                                                                               Format(LN_estadio3, "####.00000"), _
                                                                               Format(ecm_variavel_estadio3, "####.0000000000"), _
                                                                               Format(es1_variavel_estadio3, "####.0000000000"), _
                                                                               Format(es2_variavel_estadio3, "####.0000000000"), _
                                                                               Format(momento_variavel_estadio3, "####.00000"), _
                                                                               "0")

                        For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                            If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * (3 * momento_variavel_estadio3 / 4) And _
                                                        frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (3 * momento_variavel_estadio3 / 4) Then

                                ecm_resultado_parte1_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                LN_resultado_parte1_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()

                                Exit For

                            End If

                        Next

                        For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                            If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * (momento_variavel_estadio3 / 2) And _
                                                            frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (momento_variavel_estadio3 / 2) Then

                                ecm_resultado_parte2_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                LN_resultado_parte2_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()

                                Exit For

                            End If

                        Next


                        deflexao_estadio3 = ((comprimento_vao ^ 2) / 48) * _
((momento_variavel_estadio3 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1 / (4 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_LN_Estadio1)) + _
(3 * ecm_resultado_parte1_estadio3 / LN_resultado_parte1_estadio3) + _
(ecm_resultado_parte2_estadio3 / LN_resultado_parte2_estadio3) + _
                            (ecm_variavel_estadio3 / LN_estadio3))

                        'ADD
                        My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Item(My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1).Cells(7).Value = Format(deflexao_estadio3, "####.0000000000")


                        '   QUARTA VERIFICACAO

                    ElseIf momento_variavel_estadio3 / 4 > Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1 Then

                        My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Add(j, "Regime Nao Linear (Estadio 3) - 4", _
                                                                                   Format(LN_estadio3, "####.00000"), _
                                                                                   Format(ecm_variavel_estadio3, "####.0000000000"), _
                                                                                   Format(es1_variavel_estadio3, "####.0000000000"), _
                                                                                   Format(es2_variavel_estadio3, "####.0000000000"), _
                                                                                   Format(momento_variavel_estadio3, "####.00000"), _
                                                                                   "0")

                        For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                            If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * 3 * momento_variavel_estadio3 / 4 And frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (3 * momento_variavel_estadio3 / 4) Then

                                ecm_resultado_parte1_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                LN_resultado_parte1_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()


                                Exit For

                            End If

                        Next

                        For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                            If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * (momento_variavel_estadio3 / 2) And _
                                                            frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (momento_variavel_estadio3 / 2) Then

                                ecm_resultado_parte2_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                LN_resultado_parte2_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()


                                Exit For

                            End If

                        Next

                        For a As Int64 = 0 To My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1 Step 1

                            If frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() <= 1.01 * (momento_variavel_estadio3 / 4) And frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(6).Value.ToString() >= 0.99 * (momento_variavel_estadio3 / 4) Then

                                ecm_resultado_parte3_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(3).Value.ToString()

                                LN_resultado_parte3_estadio3 = frm_Resultado.DataGrid_Resultado_Estadio2.Rows(a).Cells(2).Value.ToString()


                                Exit For

                            End If

                        Next


                        ' calculando  deflexao
                        deflexao_estadio3 = ((comprimento_vao ^ 2) / 48) * ((ecm_resultado_parte3_estadio3 / LN_resultado_parte3_estadio3) + _
                        (ecm_resultado_parte2_estadio3 / LN_resultado_parte2_estadio3) + (3 * ecm_resultado_parte1_estadio3 / LN_resultado_parte1_estadio3) + _
                                             (ecm_variavel_estadio3 / LN_estadio3))

                        'ADD
                        My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Item(My.Forms.frm_Resultado.DataGrid_Resultado_Estadio2.Rows.Count - 1).Cells(7).Value = Format(deflexao_estadio3, "####.0000000000")

                    End If

                    ecm_variavel_estadio3 = ecm_variavel_estadio3 * 1.01 ' ACRESCENTA EM 1% A DEFORMACAO

                Else

                    Exit For

                End If

            Next j


            ' EXIBICAO DOS RESULTADOS

            My.Forms.frm_Resultado.TabControl_Resultado.SelectedTab = frm_Resultado.tab_estadio1

            frm_Resultado.Show()

        End If


    End Sub



    ' -------------------------------------------------------------------------------------------------------------------------------------------

    Private Sub Btn_Limpar_Rec_Click(sender As Object, e As EventArgs) Handles Btn_Limpar_Secao.Click

        txt_fck.Text = ""
        txt_ftk.Text = ""
        txt_modulo_concreto.Text = ""
        txt_comprimento_vao.Text = ""

        txt_aco_compressao.Text = ""
        txt_aco_tracao.Text = ""
        txt_modulo_aco.Text = ""
        txt_fy_aco.Text = ""

        txt_altura.Text = ""
        txt_altura_util.Text = ""
        txt_largura.Text = ""
        txt_largura.Text = ""

    End Sub


    Private Sub txt_altura_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_altura.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub

    Private Sub txt_altura_util_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_altura_util.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub


    Private Sub txt_largura_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_largura.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub

    Private Sub txt_comprimento_vao_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_comprimento_vao.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub


    Private Sub txt_fck_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_fck.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub


    Private Sub txt_ftk_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_ftk.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub


    Private Sub txt_modulo_concreto_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_modulo_concreto.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub

    Private Sub txt_fy_aco_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_fy_aco.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub

    Private Sub txt_aco_compressao_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_aco_compressao.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub


    Private Sub txt_aco_tracao_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_aco_tracao.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub


    Private Sub txt_modulo_aco_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_modulo_aco.KeyPress

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub


    Private Sub txt_escoamento_aco_KeyPress(sender As Object, e As KeyPressEventArgs)

        '---Se o textbox esta vazio e o usuario pressionou um caractere decimal ---
        If CType(sender, TextBox).Text = String.Empty And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return
        End If

        '---Se o textbox já possui um ponto decimal---
        If CType(sender, TextBox).Text.Contains(Chr(44)) And e.KeyChar = Chr(44) Then
            e.Handled = True
            Return

        End If

        '---se a tecla pressionada não é um número decimal valido ---
        If (Not (Char.IsDigit(e.KeyChar) Or Char.IsControl(e.KeyChar) Or (e.KeyChar = Chr(44)))) Then
            e.Handled = True
        End If

    End Sub

    Private Sub txt_intervalo_KeyPress(sender As Object, e As KeyPressEventArgs)

        If Not (Char.IsDigit(e.KeyChar) OrElse Char.IsControl(e.KeyChar)) Then

            e.Handled = True

        End If

    End Sub

    Private Sub MenuPrincipalToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MenuPrincipalToolStripMenuItem.Click

        frm_Menu_Principal.Show()

        Me.Close()

    End Sub

    Private Sub AjudaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AjudaToolStripMenuItem.Click

        frm_Ajuda.Show()

        Me.Close()

    End Sub
End Class



