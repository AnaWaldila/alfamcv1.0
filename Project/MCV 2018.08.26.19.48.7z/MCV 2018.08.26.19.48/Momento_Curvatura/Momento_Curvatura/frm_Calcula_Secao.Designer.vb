﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Calcula_Secao
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Calcula_Secao))
        Me.tab_secao = New MetroFramework.Controls.MetroTabPage()
        Me.btn_Calcular = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.MetroLabel2 = New MetroFramework.Controls.MetroLabel()
        Me.txt_fy_aco = New System.Windows.Forms.TextBox()
        Me.MetroLabel10 = New MetroFramework.Controls.MetroLabel()
        Me.txt_aco_compressao = New System.Windows.Forms.TextBox()
        Me.txt_aco_tracao = New System.Windows.Forms.TextBox()
        Me.MetroLabel12 = New MetroFramework.Controls.MetroLabel()
        Me.txt_modulo_aco = New System.Windows.Forms.TextBox()
        Me.MetroLabel13 = New MetroFramework.Controls.MetroLabel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txt_ftk = New System.Windows.Forms.TextBox()
        Me.MetroLabel19 = New MetroFramework.Controls.MetroLabel()
        Me.txt_modulo_concreto = New System.Windows.Forms.TextBox()
        Me.MetroLabel3 = New MetroFramework.Controls.MetroLabel()
        Me.txt_fck = New System.Windows.Forms.TextBox()
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.Btn_Limpar_Secao = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txt_comprimento_vao = New System.Windows.Forms.TextBox()
        Me.MetroLabel7 = New MetroFramework.Controls.MetroLabel()
        Me.txt_largura = New System.Windows.Forms.TextBox()
        Me.MetroLabel4 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel5 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel6 = New MetroFramework.Controls.MetroLabel()
        Me.txt_altura = New System.Windows.Forms.TextBox()
        Me.txt_altura_util = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuPrincipalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AjudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tab_secao.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabControl1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tab_secao
        '
        Me.tab_secao.AutoScroll = True
        Me.tab_secao.Controls.Add(Me.btn_Calcular)
        Me.tab_secao.Controls.Add(Me.GroupBox3)
        Me.tab_secao.Controls.Add(Me.GroupBox1)
        Me.tab_secao.Controls.Add(Me.Btn_Limpar_Secao)
        Me.tab_secao.Controls.Add(Me.GroupBox2)
        Me.tab_secao.Controls.Add(Me.PictureBox1)
        Me.tab_secao.HorizontalScrollbar = True
        Me.tab_secao.HorizontalScrollbarBarColor = True
        Me.tab_secao.HorizontalScrollbarHighlightOnWheel = False
        Me.tab_secao.HorizontalScrollbarSize = 10
        Me.tab_secao.Location = New System.Drawing.Point(4, 38)
        Me.tab_secao.Name = "tab_secao"
        Me.tab_secao.Size = New System.Drawing.Size(852, 586)
        Me.tab_secao.TabIndex = 0
        Me.tab_secao.Text = "Geometria da Seçao e Dados dos Materiais"
        Me.tab_secao.VerticalScrollbar = True
        Me.tab_secao.VerticalScrollbarBarColor = True
        Me.tab_secao.VerticalScrollbarHighlightOnWheel = False
        Me.tab_secao.VerticalScrollbarSize = 10
        '
        'btn_Calcular
        '
        Me.btn_Calcular.BackColor = System.Drawing.Color.White
        Me.btn_Calcular.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Calcular.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Calcular.ForeColor = System.Drawing.Color.Navy
        Me.btn_Calcular.Location = New System.Drawing.Point(574, 335)
        Me.btn_Calcular.Name = "btn_Calcular"
        Me.btn_Calcular.Size = New System.Drawing.Size(200, 40)
        Me.btn_Calcular.TabIndex = 3
        Me.btn_Calcular.Text = "Calcular"
        Me.btn_Calcular.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.MetroLabel2)
        Me.GroupBox3.Controls.Add(Me.txt_fy_aco)
        Me.GroupBox3.Controls.Add(Me.MetroLabel10)
        Me.GroupBox3.Controls.Add(Me.txt_aco_compressao)
        Me.GroupBox3.Controls.Add(Me.txt_aco_tracao)
        Me.GroupBox3.Controls.Add(Me.MetroLabel12)
        Me.GroupBox3.Controls.Add(Me.txt_modulo_aco)
        Me.GroupBox3.Controls.Add(Me.MetroLabel13)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(3, 381)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(500, 200)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Características do Aço"
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.Location = New System.Drawing.Point(20, 160)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(172, 19)
        Me.MetroLabel2.TabIndex = 3
        Me.MetroLabel2.Text = "Escoamento Aço - fy (MPa):"
        '
        'txt_fy_aco
        '
        Me.txt_fy_aco.Location = New System.Drawing.Point(344, 160)
        Me.txt_fy_aco.Name = "txt_fy_aco"
        Me.txt_fy_aco.Size = New System.Drawing.Size(150, 22)
        Me.txt_fy_aco.TabIndex = 3
        Me.txt_fy_aco.Text = "275,8"
        '
        'MetroLabel10
        '
        Me.MetroLabel10.AutoSize = True
        Me.MetroLabel10.Location = New System.Drawing.Point(20, 120)
        Me.MetroLabel10.Name = "MetroLabel10"
        Me.MetroLabel10.Size = New System.Drawing.Size(260, 19)
        Me.MetroLabel10.TabIndex = 2
        Me.MetroLabel10.Text = "Módulo de Elasticidade do Aço - Es (MPa):"
        '
        'txt_aco_compressao
        '
        Me.txt_aco_compressao.Location = New System.Drawing.Point(344, 40)
        Me.txt_aco_compressao.Name = "txt_aco_compressao"
        Me.txt_aco_compressao.Size = New System.Drawing.Size(150, 22)
        Me.txt_aco_compressao.TabIndex = 0
        Me.txt_aco_compressao.Text = "0"
        '
        'txt_aco_tracao
        '
        Me.txt_aco_tracao.Location = New System.Drawing.Point(344, 80)
        Me.txt_aco_tracao.Name = "txt_aco_tracao"
        Me.txt_aco_tracao.Size = New System.Drawing.Size(150, 22)
        Me.txt_aco_tracao.TabIndex = 1
        Me.txt_aco_tracao.Text = "32,258"
        '
        'MetroLabel12
        '
        Me.MetroLabel12.AutoSize = True
        Me.MetroLabel12.Location = New System.Drawing.Point(20, 40)
        Me.MetroLabel12.Name = "MetroLabel12"
        Me.MetroLabel12.Size = New System.Drawing.Size(253, 19)
        Me.MetroLabel12.TabIndex = 0
        Me.MetroLabel12.Text = "Área de Aço de Compressao - As' (cm²): "
        '
        'txt_modulo_aco
        '
        Me.txt_modulo_aco.Location = New System.Drawing.Point(344, 120)
        Me.txt_modulo_aco.Name = "txt_modulo_aco"
        Me.txt_modulo_aco.Size = New System.Drawing.Size(150, 22)
        Me.txt_modulo_aco.TabIndex = 2
        Me.txt_modulo_aco.Text = "199955"
        '
        'MetroLabel13
        '
        Me.MetroLabel13.AutoSize = True
        Me.MetroLabel13.Location = New System.Drawing.Point(20, 80)
        Me.MetroLabel13.Name = "MetroLabel13"
        Me.MetroLabel13.Size = New System.Drawing.Size(210, 19)
        Me.MetroLabel13.TabIndex = 1
        Me.MetroLabel13.Text = "Área de Aço de Traçao - As (cm²):"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.txt_ftk)
        Me.GroupBox1.Controls.Add(Me.MetroLabel19)
        Me.GroupBox1.Controls.Add(Me.txt_modulo_concreto)
        Me.GroupBox1.Controls.Add(Me.MetroLabel3)
        Me.GroupBox1.Controls.Add(Me.txt_fck)
        Me.GroupBox1.Controls.Add(Me.MetroLabel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(3, 215)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(500, 160)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Características do Concreto"
        '
        'txt_ftk
        '
        Me.txt_ftk.Location = New System.Drawing.Point(344, 80)
        Me.txt_ftk.Name = "txt_ftk"
        Me.txt_ftk.Size = New System.Drawing.Size(150, 22)
        Me.txt_ftk.TabIndex = 1
        Me.txt_ftk.Text = "3,10275"
        '
        'MetroLabel19
        '
        Me.MetroLabel19.AutoSize = True
        Me.MetroLabel19.Location = New System.Drawing.Point(20, 80)
        Me.MetroLabel19.Name = "MetroLabel19"
        Me.MetroLabel19.Size = New System.Drawing.Size(251, 19)
        Me.MetroLabel19.TabIndex = 1
        Me.MetroLabel19.Text = "Resistencia à Traçao Concreto - ftk (MPa):"
        '
        'txt_modulo_concreto
        '
        Me.txt_modulo_concreto.Location = New System.Drawing.Point(344, 120)
        Me.txt_modulo_concreto.Name = "txt_modulo_concreto"
        Me.txt_modulo_concreto.Size = New System.Drawing.Size(150, 22)
        Me.txt_modulo_concreto.TabIndex = 2
        Me.txt_modulo_concreto.Text = "23580,9"
        '
        'MetroLabel3
        '
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.Location = New System.Drawing.Point(20, 120)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(265, 19)
        Me.MetroLabel3.TabIndex = 2
        Me.MetroLabel3.Text = "Módulo de Elasticidade do Concreto (MPa):"
        '
        'txt_fck
        '
        Me.txt_fck.Location = New System.Drawing.Point(344, 40)
        Me.txt_fck.Name = "txt_fck"
        Me.txt_fck.Size = New System.Drawing.Size(150, 22)
        Me.txt_fck.TabIndex = 0
        Me.txt_fck.Text = "24,822"
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.Location = New System.Drawing.Point(20, 40)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(293, 19)
        Me.MetroLabel1.TabIndex = 0
        Me.MetroLabel1.Text = "Resistencia à Compressao Concreto - fck (MPa): "
        '
        'Btn_Limpar_Secao
        '
        Me.Btn_Limpar_Secao.BackColor = System.Drawing.Color.White
        Me.Btn_Limpar_Secao.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Limpar_Secao.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Limpar_Secao.ForeColor = System.Drawing.Color.Navy
        Me.Btn_Limpar_Secao.Location = New System.Drawing.Point(574, 381)
        Me.Btn_Limpar_Secao.Name = "Btn_Limpar_Secao"
        Me.Btn_Limpar_Secao.Size = New System.Drawing.Size(200, 40)
        Me.Btn_Limpar_Secao.TabIndex = 4
        Me.Btn_Limpar_Secao.Text = "Limpar Campos"
        Me.Btn_Limpar_Secao.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.txt_comprimento_vao)
        Me.GroupBox2.Controls.Add(Me.MetroLabel7)
        Me.GroupBox2.Controls.Add(Me.txt_largura)
        Me.GroupBox2.Controls.Add(Me.MetroLabel4)
        Me.GroupBox2.Controls.Add(Me.MetroLabel5)
        Me.GroupBox2.Controls.Add(Me.MetroLabel6)
        Me.GroupBox2.Controls.Add(Me.txt_altura)
        Me.GroupBox2.Controls.Add(Me.txt_altura_util)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(500, 206)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Características da Seçao"
        '
        'txt_comprimento_vao
        '
        Me.txt_comprimento_vao.Location = New System.Drawing.Point(344, 160)
        Me.txt_comprimento_vao.Name = "txt_comprimento_vao"
        Me.txt_comprimento_vao.Size = New System.Drawing.Size(150, 22)
        Me.txt_comprimento_vao.TabIndex = 3
        Me.txt_comprimento_vao.Text = "457,2"
        '
        'MetroLabel7
        '
        Me.MetroLabel7.AutoSize = True
        Me.MetroLabel7.Location = New System.Drawing.Point(20, 160)
        Me.MetroLabel7.Name = "MetroLabel7"
        Me.MetroLabel7.Size = New System.Drawing.Size(63, 19)
        Me.MetroLabel7.TabIndex = 3
        Me.MetroLabel7.Text = "Vao (cm):"
        '
        'txt_largura
        '
        Me.txt_largura.Location = New System.Drawing.Point(344, 120)
        Me.txt_largura.Name = "txt_largura"
        Me.txt_largura.Size = New System.Drawing.Size(150, 22)
        Me.txt_largura.TabIndex = 2
        Me.txt_largura.Text = "30,48"
        '
        'MetroLabel4
        '
        Me.MetroLabel4.AutoSize = True
        Me.MetroLabel4.Location = New System.Drawing.Point(20, 40)
        Me.MetroLabel4.Name = "MetroLabel4"
        Me.MetroLabel4.Size = New System.Drawing.Size(135, 19)
        Me.MetroLabel4.TabIndex = 0
        Me.MetroLabel4.Text = "Altura Total - H (cm): "
        '
        'MetroLabel5
        '
        Me.MetroLabel5.AutoSize = True
        Me.MetroLabel5.Location = New System.Drawing.Point(20, 80)
        Me.MetroLabel5.Name = "MetroLabel5"
        Me.MetroLabel5.Size = New System.Drawing.Size(162, 19)
        Me.MetroLabel5.TabIndex = 1
        Me.MetroLabel5.Text = "Altura Útil Total - d (cm²): "
        '
        'MetroLabel6
        '
        Me.MetroLabel6.AutoSize = True
        Me.MetroLabel6.Location = New System.Drawing.Point(20, 120)
        Me.MetroLabel6.Name = "MetroLabel6"
        Me.MetroLabel6.Size = New System.Drawing.Size(109, 19)
        Me.MetroLabel6.TabIndex = 2
        Me.MetroLabel6.Text = "Largura - B (cm):"
        '
        'txt_altura
        '
        Me.txt_altura.Location = New System.Drawing.Point(344, 40)
        Me.txt_altura.Name = "txt_altura"
        Me.txt_altura.Size = New System.Drawing.Size(150, 22)
        Me.txt_altura.TabIndex = 0
        Me.txt_altura.Text = "60,96"
        '
        'txt_altura_util
        '
        Me.txt_altura_util.Location = New System.Drawing.Point(344, 80)
        Me.txt_altura_util.Name = "txt_altura_util"
        Me.txt_altura_util.Size = New System.Drawing.Size(150, 22)
        Me.txt_altura_util.TabIndex = 1
        Me.txt_altura_util.Text = "50,8"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(574, 43)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(200, 251)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Controls.Add(Me.tab_secao)
        Me.MetroTabControl1.Location = New System.Drawing.Point(12, 27)
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.Size = New System.Drawing.Size(860, 628)
        Me.MetroTabControl1.TabIndex = 1
        Me.MetroTabControl1.UseSelectable = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuPrincipalToolStripMenuItem, Me.AjudaToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(884, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuPrincipalToolStripMenuItem
        '
        Me.MenuPrincipalToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuPrincipalToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.MenuPrincipalToolStripMenuItem.Name = "MenuPrincipalToolStripMenuItem"
        Me.MenuPrincipalToolStripMenuItem.Size = New System.Drawing.Size(122, 20)
        Me.MenuPrincipalToolStripMenuItem.Text = "Menu Principal"
        '
        'AjudaToolStripMenuItem
        '
        Me.AjudaToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AjudaToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.AjudaToolStripMenuItem.Name = "AjudaToolStripMenuItem"
        Me.AjudaToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.AjudaToolStripMenuItem.Text = "Ajuda"
        '
        'frm_Calcula_Secao
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(884, 661)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.Name = "frm_Calcula_Secao"
        Me.Text = "Cálculo da Seçao"
        Me.tab_secao.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabControl1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tab_secao As MetroFramework.Controls.MetroTabPage
    Friend WithEvents Btn_Limpar_Secao As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents MetroLabel4 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel5 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_altura As System.Windows.Forms.TextBox
    Friend WithEvents txt_altura_util As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents txt_largura As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel6 As MetroFramework.Controls.MetroLabel
    Friend WithEvents btn_Calcular As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents MetroLabel10 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_aco_compressao As System.Windows.Forms.TextBox
    Friend WithEvents txt_aco_tracao As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel12 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_modulo_aco As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel13 As MetroFramework.Controls.MetroLabel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_ftk As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel19 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_modulo_concreto As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel3 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_fck As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MenuPrincipalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AjudaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txt_fy_aco As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel2 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_comprimento_vao As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel7 As MetroFramework.Controls.MetroLabel

End Class
