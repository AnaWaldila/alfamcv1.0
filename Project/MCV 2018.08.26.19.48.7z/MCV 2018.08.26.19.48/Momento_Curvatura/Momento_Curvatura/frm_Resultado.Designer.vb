﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Resultado
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Resultado))
        Me.TabControl_Resultado = New MetroFramework.Controls.MetroTabControl()
        Me.tab_estadio1 = New MetroFramework.Controls.MetroTabPage()
        Me.txt_resultado_Aco_compressao = New System.Windows.Forms.TextBox()
        Me.txt_resultado_momento_fissuracao = New System.Windows.Forms.TextBox()
        Me.txt_resultado_aco_tracao = New System.Windows.Forms.TextBox()
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.txt_resultado_compressao_maxima_concreto = New System.Windows.Forms.TextBox()
        Me.MetroLabel2 = New MetroFramework.Controls.MetroLabel()
        Me.txt_resultado_compressao_concreto = New System.Windows.Forms.TextBox()
        Me.MetroLabel3 = New MetroFramework.Controls.MetroLabel()
        Me.txt_resultado_deformacao_tracao_concreto = New System.Windows.Forms.TextBox()
        Me.MetroLabel4 = New MetroFramework.Controls.MetroLabel()
        Me.txt_resultado_LN = New System.Windows.Forms.TextBox()
        Me.MetroLabel5 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel7 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel6 = New MetroFramework.Controls.MetroLabel()
        Me.tab_estadio2 = New MetroFramework.Controls.MetroTabPage()
        Me.DataGrid_Resultado_Estadio2 = New System.Windows.Forms.DataGridView()
        Me.clm_i = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clm_regime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clm_LN = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clm_concreto_compressao = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clm_aco_compressao = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clm_aco_tracao = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clm_momento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clm_deflexao = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuPrincipalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AjudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportarParaExcelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.TabControl_Resultado.SuspendLayout()
        Me.tab_estadio1.SuspendLayout()
        Me.tab_estadio2.SuspendLayout()
        CType(Me.DataGrid_Resultado_Estadio2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl_Resultado
        '
        Me.TabControl_Resultado.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl_Resultado.Controls.Add(Me.tab_estadio1)
        Me.TabControl_Resultado.Controls.Add(Me.tab_estadio2)
        Me.TabControl_Resultado.Location = New System.Drawing.Point(12, 27)
        Me.TabControl_Resultado.Name = "TabControl_Resultado"
        Me.TabControl_Resultado.SelectedIndex = 1
        Me.TabControl_Resultado.Size = New System.Drawing.Size(857, 522)
        Me.TabControl_Resultado.TabIndex = 2
        Me.TabControl_Resultado.UseSelectable = True
        '
        'tab_estadio1
        '
        Me.tab_estadio1.AutoScroll = True
        Me.tab_estadio1.Controls.Add(Me.txt_resultado_Aco_compressao)
        Me.tab_estadio1.Controls.Add(Me.txt_resultado_momento_fissuracao)
        Me.tab_estadio1.Controls.Add(Me.txt_resultado_aco_tracao)
        Me.tab_estadio1.Controls.Add(Me.MetroLabel1)
        Me.tab_estadio1.Controls.Add(Me.txt_resultado_compressao_maxima_concreto)
        Me.tab_estadio1.Controls.Add(Me.MetroLabel2)
        Me.tab_estadio1.Controls.Add(Me.txt_resultado_compressao_concreto)
        Me.tab_estadio1.Controls.Add(Me.MetroLabel3)
        Me.tab_estadio1.Controls.Add(Me.txt_resultado_deformacao_tracao_concreto)
        Me.tab_estadio1.Controls.Add(Me.MetroLabel4)
        Me.tab_estadio1.Controls.Add(Me.txt_resultado_LN)
        Me.tab_estadio1.Controls.Add(Me.MetroLabel5)
        Me.tab_estadio1.Controls.Add(Me.MetroLabel7)
        Me.tab_estadio1.Controls.Add(Me.MetroLabel6)
        Me.tab_estadio1.HorizontalScrollbar = True
        Me.tab_estadio1.HorizontalScrollbarBarColor = True
        Me.tab_estadio1.HorizontalScrollbarHighlightOnWheel = False
        Me.tab_estadio1.HorizontalScrollbarSize = 10
        Me.tab_estadio1.Location = New System.Drawing.Point(4, 38)
        Me.tab_estadio1.Name = "tab_estadio1"
        Me.tab_estadio1.Size = New System.Drawing.Size(849, 480)
        Me.tab_estadio1.TabIndex = 0
        Me.tab_estadio1.Text = "Regiao Linear"
        Me.tab_estadio1.VerticalScrollbar = True
        Me.tab_estadio1.VerticalScrollbarBarColor = True
        Me.tab_estadio1.VerticalScrollbarHighlightOnWheel = False
        Me.tab_estadio1.VerticalScrollbarSize = 10
        '
        'txt_resultado_Aco_compressao
        '
        Me.txt_resultado_Aco_compressao.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_resultado_Aco_compressao.Location = New System.Drawing.Point(420, 240)
        Me.txt_resultado_Aco_compressao.Name = "txt_resultado_Aco_compressao"
        Me.txt_resultado_Aco_compressao.Size = New System.Drawing.Size(150, 22)
        Me.txt_resultado_Aco_compressao.TabIndex = 27
        '
        'txt_resultado_momento_fissuracao
        '
        Me.txt_resultado_momento_fissuracao.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_resultado_momento_fissuracao.Location = New System.Drawing.Point(420, 280)
        Me.txt_resultado_momento_fissuracao.Name = "txt_resultado_momento_fissuracao"
        Me.txt_resultado_momento_fissuracao.Size = New System.Drawing.Size(150, 22)
        Me.txt_resultado_momento_fissuracao.TabIndex = 26
        '
        'txt_resultado_aco_tracao
        '
        Me.txt_resultado_aco_tracao.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_resultado_aco_tracao.Location = New System.Drawing.Point(420, 200)
        Me.txt_resultado_aco_tracao.Name = "txt_resultado_aco_tracao"
        Me.txt_resultado_aco_tracao.Size = New System.Drawing.Size(150, 22)
        Me.txt_resultado_aco_tracao.TabIndex = 25
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.Location = New System.Drawing.Point(20, 40)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(174, 19)
        Me.MetroLabel1.TabIndex = 14
        Me.MetroLabel1.Text = "Altura da Linha Neutra (cm):"
        '
        'txt_resultado_compressao_maxima_concreto
        '
        Me.txt_resultado_compressao_maxima_concreto.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_resultado_compressao_maxima_concreto.Location = New System.Drawing.Point(420, 160)
        Me.txt_resultado_compressao_maxima_concreto.Name = "txt_resultado_compressao_maxima_concreto"
        Me.txt_resultado_compressao_maxima_concreto.Size = New System.Drawing.Size(150, 22)
        Me.txt_resultado_compressao_maxima_concreto.TabIndex = 24
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.Location = New System.Drawing.Point(20, 80)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(279, 19)
        Me.MetroLabel2.TabIndex = 15
        Me.MetroLabel2.Text = "Deformaçao de Traçao Máxima do Concreto: "
        '
        'txt_resultado_compressao_concreto
        '
        Me.txt_resultado_compressao_concreto.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_resultado_compressao_concreto.Location = New System.Drawing.Point(420, 120)
        Me.txt_resultado_compressao_concreto.Name = "txt_resultado_compressao_concreto"
        Me.txt_resultado_compressao_concreto.Size = New System.Drawing.Size(150, 22)
        Me.txt_resultado_compressao_concreto.TabIndex = 23
        '
        'MetroLabel3
        '
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.Location = New System.Drawing.Point(20, 120)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(382, 19)
        Me.MetroLabel3.TabIndex = 16
        Me.MetroLabel3.Text = "Deformaçao de Compressao correspondente à Traçao Máxima:"
        '
        'txt_resultado_deformacao_tracao_concreto
        '
        Me.txt_resultado_deformacao_tracao_concreto.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_resultado_deformacao_tracao_concreto.Location = New System.Drawing.Point(420, 80)
        Me.txt_resultado_deformacao_tracao_concreto.Name = "txt_resultado_deformacao_tracao_concreto"
        Me.txt_resultado_deformacao_tracao_concreto.Size = New System.Drawing.Size(150, 22)
        Me.txt_resultado_deformacao_tracao_concreto.TabIndex = 22
        '
        'MetroLabel4
        '
        Me.MetroLabel4.AutoSize = True
        Me.MetroLabel4.Location = New System.Drawing.Point(20, 160)
        Me.MetroLabel4.Name = "MetroLabel4"
        Me.MetroLabel4.Size = New System.Drawing.Size(311, 19)
        Me.MetroLabel4.TabIndex = 17
        Me.MetroLabel4.Text = "Deformaçao de Compressao Máxima do Concreto:"
        '
        'txt_resultado_LN
        '
        Me.txt_resultado_LN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_resultado_LN.Location = New System.Drawing.Point(420, 40)
        Me.txt_resultado_LN.Name = "txt_resultado_LN"
        Me.txt_resultado_LN.Size = New System.Drawing.Size(150, 22)
        Me.txt_resultado_LN.TabIndex = 21
        '
        'MetroLabel5
        '
        Me.MetroLabel5.AutoSize = True
        Me.MetroLabel5.Location = New System.Drawing.Point(20, 200)
        Me.MetroLabel5.Name = "MetroLabel5"
        Me.MetroLabel5.Size = New System.Drawing.Size(193, 19)
        Me.MetroLabel5.TabIndex = 18
        Me.MetroLabel5.Text = "Deformaçao do Aço de Traçao:"
        '
        'MetroLabel7
        '
        Me.MetroLabel7.AutoSize = True
        Me.MetroLabel7.Location = New System.Drawing.Point(20, 280)
        Me.MetroLabel7.Name = "MetroLabel7"
        Me.MetroLabel7.Size = New System.Drawing.Size(196, 19)
        Me.MetroLabel7.TabIndex = 20
        Me.MetroLabel7.Text = "Momento de Fissuraçao (kN.m):"
        '
        'MetroLabel6
        '
        Me.MetroLabel6.AutoSize = True
        Me.MetroLabel6.Location = New System.Drawing.Point(20, 240)
        Me.MetroLabel6.Name = "MetroLabel6"
        Me.MetroLabel6.Size = New System.Drawing.Size(229, 19)
        Me.MetroLabel6.TabIndex = 19
        Me.MetroLabel6.Text = "Deformaçao do Aço de Compressao:"
        '
        'tab_estadio2
        '
        Me.tab_estadio2.Controls.Add(Me.DataGrid_Resultado_Estadio2)
        Me.tab_estadio2.HorizontalScrollbarBarColor = True
        Me.tab_estadio2.HorizontalScrollbarHighlightOnWheel = False
        Me.tab_estadio2.HorizontalScrollbarSize = 10
        Me.tab_estadio2.Location = New System.Drawing.Point(4, 38)
        Me.tab_estadio2.Name = "tab_estadio2"
        Me.tab_estadio2.Size = New System.Drawing.Size(849, 480)
        Me.tab_estadio2.TabIndex = 1
        Me.tab_estadio2.Text = "Regiao Nao Linear"
        Me.tab_estadio2.VerticalScrollbarBarColor = True
        Me.tab_estadio2.VerticalScrollbarHighlightOnWheel = False
        Me.tab_estadio2.VerticalScrollbarSize = 10
        '
        'DataGrid_Resultado_Estadio2
        '
        Me.DataGrid_Resultado_Estadio2.AllowUserToAddRows = False
        Me.DataGrid_Resultado_Estadio2.AllowUserToDeleteRows = False
        Me.DataGrid_Resultado_Estadio2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGrid_Resultado_Estadio2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGrid_Resultado_Estadio2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGrid_Resultado_Estadio2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.clm_i, Me.clm_regime, Me.clm_LN, Me.clm_concreto_compressao, Me.clm_aco_compressao, Me.clm_aco_tracao, Me.clm_momento, Me.clm_deflexao})
        Me.DataGrid_Resultado_Estadio2.Location = New System.Drawing.Point(3, 3)
        Me.DataGrid_Resultado_Estadio2.Name = "DataGrid_Resultado_Estadio2"
        Me.DataGrid_Resultado_Estadio2.ReadOnly = True
        Me.DataGrid_Resultado_Estadio2.Size = New System.Drawing.Size(843, 474)
        Me.DataGrid_Resultado_Estadio2.TabIndex = 4
        '
        'clm_i
        '
        Me.clm_i.HeaderText = "Índice i"
        Me.clm_i.Name = "clm_i"
        Me.clm_i.ReadOnly = True
        '
        'clm_regime
        '
        Me.clm_regime.HeaderText = "Tipo de Regime"
        Me.clm_regime.Name = "clm_regime"
        Me.clm_regime.ReadOnly = True
        '
        'clm_LN
        '
        Me.clm_LN.HeaderText = "Linha Neutra (cm)"
        Me.clm_LN.Name = "clm_LN"
        Me.clm_LN.ReadOnly = True
        '
        'clm_concreto_compressao
        '
        Me.clm_concreto_compressao.HeaderText = "Deformacao Compressao Concreto"
        Me.clm_concreto_compressao.Name = "clm_concreto_compressao"
        Me.clm_concreto_compressao.ReadOnly = True
        '
        'clm_aco_compressao
        '
        Me.clm_aco_compressao.HeaderText = "Deformacao Compressao do Aco"
        Me.clm_aco_compressao.Name = "clm_aco_compressao"
        Me.clm_aco_compressao.ReadOnly = True
        '
        'clm_aco_tracao
        '
        Me.clm_aco_tracao.HeaderText = "Deformacao Tracao Aco"
        Me.clm_aco_tracao.Name = "clm_aco_tracao"
        Me.clm_aco_tracao.ReadOnly = True
        '
        'clm_momento
        '
        Me.clm_momento.HeaderText = "Momento (kN.m)"
        Me.clm_momento.Name = "clm_momento"
        Me.clm_momento.ReadOnly = True
        '
        'clm_deflexao
        '
        Me.clm_deflexao.HeaderText = "Deflexão (cm)"
        Me.clm_deflexao.Name = "clm_deflexao"
        Me.clm_deflexao.ReadOnly = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuPrincipalToolStripMenuItem, Me.AjudaToolStripMenuItem, Me.ExportarParaExcelToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(884, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuPrincipalToolStripMenuItem
        '
        Me.MenuPrincipalToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuPrincipalToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.MenuPrincipalToolStripMenuItem.Name = "MenuPrincipalToolStripMenuItem"
        Me.MenuPrincipalToolStripMenuItem.Size = New System.Drawing.Size(122, 20)
        Me.MenuPrincipalToolStripMenuItem.Text = "Menu Principal"
        '
        'AjudaToolStripMenuItem
        '
        Me.AjudaToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AjudaToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.AjudaToolStripMenuItem.Name = "AjudaToolStripMenuItem"
        Me.AjudaToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.AjudaToolStripMenuItem.Text = "Ajuda"
        '
        'ExportarParaExcelToolStripMenuItem
        '
        Me.ExportarParaExcelToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExportarParaExcelToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ExportarParaExcelToolStripMenuItem.Name = "ExportarParaExcelToolStripMenuItem"
        Me.ExportarParaExcelToolStripMenuItem.Size = New System.Drawing.Size(156, 20)
        Me.ExportarParaExcelToolStripMenuItem.Text = "Exportar para Excel"
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'frm_Resultado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(884, 561)
        Me.Controls.Add(Me.TabControl_Resultado)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frm_Resultado"
        Me.Text = "Resultado"
        Me.TabControl_Resultado.ResumeLayout(False)
        Me.tab_estadio1.ResumeLayout(False)
        Me.tab_estadio1.PerformLayout()
        Me.tab_estadio2.ResumeLayout(False)
        CType(Me.DataGrid_Resultado_Estadio2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl_Resultado As MetroFramework.Controls.MetroTabControl
    Friend WithEvents tab_estadio1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents txt_resultado_Aco_compressao As System.Windows.Forms.TextBox
    Friend WithEvents txt_resultado_momento_fissuracao As System.Windows.Forms.TextBox
    Friend WithEvents txt_resultado_aco_tracao As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_resultado_compressao_maxima_concreto As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel2 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_resultado_compressao_concreto As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel3 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_resultado_deformacao_tracao_concreto As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel4 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txt_resultado_LN As System.Windows.Forms.TextBox
    Friend WithEvents MetroLabel5 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel7 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel6 As MetroFramework.Controls.MetroLabel
    Friend WithEvents tab_estadio2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MenuPrincipalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AjudaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataGrid_Resultado_Estadio2 As System.Windows.Forms.DataGridView
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents ExportarParaExcelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents clm_i As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clm_regime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clm_LN As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clm_concreto_compressao As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clm_aco_compressao As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clm_aco_tracao As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clm_momento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clm_deflexao As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
