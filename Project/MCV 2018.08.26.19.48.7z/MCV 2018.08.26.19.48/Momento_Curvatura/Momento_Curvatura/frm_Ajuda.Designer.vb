﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Ajuda
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Ajuda))
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.tab_software = New MetroFramework.Controls.MetroTabPage()
        Me.RichTextBox4 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.tab_referencias = New MetroFramework.Controls.MetroTabPage()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuPrincipalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CálculoMomentoXDeformaçaoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RichTextBox5 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox6 = New System.Windows.Forms.RichTextBox()
        Me.MetroTabControl1.SuspendLayout()
        Me.tab_software.SuspendLayout()
        Me.tab_referencias.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MetroTabControl1.Controls.Add(Me.tab_software)
        Me.MetroTabControl1.Controls.Add(Me.tab_referencias)
        Me.MetroTabControl1.Location = New System.Drawing.Point(12, 27)
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 1
        Me.MetroTabControl1.Size = New System.Drawing.Size(725, 415)
        Me.MetroTabControl1.TabIndex = 0
        Me.MetroTabControl1.UseSelectable = True
        '
        'tab_software
        '
        Me.tab_software.Controls.Add(Me.RichTextBox4)
        Me.tab_software.Controls.Add(Me.RichTextBox3)
        Me.tab_software.Controls.Add(Me.RichTextBox2)
        Me.tab_software.Controls.Add(Me.RichTextBox1)
        Me.tab_software.HorizontalScrollbarBarColor = True
        Me.tab_software.HorizontalScrollbarHighlightOnWheel = False
        Me.tab_software.HorizontalScrollbarSize = 10
        Me.tab_software.Location = New System.Drawing.Point(4, 38)
        Me.tab_software.Name = "tab_software"
        Me.tab_software.Size = New System.Drawing.Size(717, 373)
        Me.tab_software.TabIndex = 0
        Me.tab_software.Text = "Utilizando o Software"
        Me.tab_software.VerticalScrollbarBarColor = True
        Me.tab_software.VerticalScrollbarHighlightOnWheel = False
        Me.tab_software.VerticalScrollbarSize = 10
        '
        'RichTextBox4
        '
        Me.RichTextBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox4.BackColor = System.Drawing.Color.White
        Me.RichTextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox4.Location = New System.Drawing.Point(10, 154)
        Me.RichTextBox4.Name = "RichTextBox4"
        Me.RichTextBox4.ReadOnly = True
        Me.RichTextBox4.Size = New System.Drawing.Size(704, 57)
        Me.RichTextBox4.TabIndex = 5
        Me.RichTextBox4.Text = resources.GetString("RichTextBox4.Text")
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox3.BackColor = System.Drawing.Color.White
        Me.RichTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox3.Location = New System.Drawing.Point(10, 91)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.ReadOnly = True
        Me.RichTextBox3.Size = New System.Drawing.Size(704, 57)
        Me.RichTextBox3.TabIndex = 4
        Me.RichTextBox3.Text = resources.GetString("RichTextBox3.Text")
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox2.BackColor = System.Drawing.Color.White
        Me.RichTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox2.Location = New System.Drawing.Point(10, 57)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.ReadOnly = True
        Me.RichTextBox2.Size = New System.Drawing.Size(704, 41)
        Me.RichTextBox2.TabIndex = 3
        Me.RichTextBox2.Text = "O programa possui o ""Menu Principal"", disponível de 4 botões: ""Cálculos"", ""Ajuda""" &
    ", ""Sobre o Software"" e ""Sair""."
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox1.BackColor = System.Drawing.Color.White
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(10, 10)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.Size = New System.Drawing.Size(704, 41)
        Me.RichTextBox1.TabIndex = 2
        Me.RichTextBox1.Text = "AlfaMDV é um programa fácil e versátil que possibilita gerar a curva Momento x De" &
    "formação de seções de vigas retangulares de concreto armado. "
        '
        'tab_referencias
        '
        Me.tab_referencias.Controls.Add(Me.RichTextBox6)
        Me.tab_referencias.Controls.Add(Me.RichTextBox5)
        Me.tab_referencias.HorizontalScrollbarBarColor = True
        Me.tab_referencias.HorizontalScrollbarHighlightOnWheel = False
        Me.tab_referencias.HorizontalScrollbarSize = 10
        Me.tab_referencias.Location = New System.Drawing.Point(4, 38)
        Me.tab_referencias.Name = "tab_referencias"
        Me.tab_referencias.Size = New System.Drawing.Size(717, 373)
        Me.tab_referencias.TabIndex = 1
        Me.tab_referencias.Text = "Referencias"
        Me.tab_referencias.VerticalScrollbarBarColor = True
        Me.tab_referencias.VerticalScrollbarHighlightOnWheel = False
        Me.tab_referencias.VerticalScrollbarSize = 10
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuPrincipalToolStripMenuItem, Me.CálculoMomentoXDeformaçaoToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(749, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuPrincipalToolStripMenuItem
        '
        Me.MenuPrincipalToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuPrincipalToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.MenuPrincipalToolStripMenuItem.Name = "MenuPrincipalToolStripMenuItem"
        Me.MenuPrincipalToolStripMenuItem.Size = New System.Drawing.Size(122, 20)
        Me.MenuPrincipalToolStripMenuItem.Text = "Menu Principal"
        '
        'CálculoMomentoXDeformaçaoToolStripMenuItem
        '
        Me.CálculoMomentoXDeformaçaoToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CálculoMomentoXDeformaçaoToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.CálculoMomentoXDeformaçaoToolStripMenuItem.Name = "CálculoMomentoXDeformaçaoToolStripMenuItem"
        Me.CálculoMomentoXDeformaçaoToolStripMenuItem.Size = New System.Drawing.Size(239, 20)
        Me.CálculoMomentoXDeformaçaoToolStripMenuItem.Text = "Cálculo Momento x Deformaçao"
        '
        'RichTextBox5
        '
        Me.RichTextBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox5.BackColor = System.Drawing.Color.White
        Me.RichTextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox5.Location = New System.Drawing.Point(10, 10)
        Me.RichTextBox5.Name = "RichTextBox5"
        Me.RichTextBox5.ReadOnly = True
        Me.RichTextBox5.Size = New System.Drawing.Size(704, 41)
        Me.RichTextBox5.TabIndex = 3
        Me.RichTextBox5.Text = "O processo de criação do software e sua formulação, tento como as outras referênc" &
    "ias, está disponível no trabalho cuja referência está abaixo:"
        '
        'RichTextBox6
        '
        Me.RichTextBox6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox6.BackColor = System.Drawing.Color.White
        Me.RichTextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox6.Location = New System.Drawing.Point(10, 60)
        Me.RichTextBox6.Name = "RichTextBox6"
        Me.RichTextBox6.ReadOnly = True
        Me.RichTextBox6.Size = New System.Drawing.Size(704, 41)
        Me.RichTextBox6.TabIndex = 4
        Me.RichTextBox6.Text = "REIS,  A.  W.  de  Q.  R.,  Modelagem  Numérica  de  Seções  de  Concreto  Armado" &
    ".  Universidade  do  Estado  do  Rio  de  Janeiro.  Rio  de  Janeiro  –  RJ,  20" &
    "17.  "
        '
        'frm_Ajuda
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(749, 454)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frm_Ajuda"
        Me.Text = "frm_Ajuda"
        Me.MetroTabControl1.ResumeLayout(False)
        Me.tab_software.ResumeLayout(False)
        Me.tab_referencias.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents tab_software As MetroFramework.Controls.MetroTabPage
    Friend WithEvents tab_referencias As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MenuPrincipalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CálculoMomentoXDeformaçaoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RichTextBox4 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox3 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox6 As RichTextBox
    Friend WithEvents RichTextBox5 As RichTextBox
End Class
