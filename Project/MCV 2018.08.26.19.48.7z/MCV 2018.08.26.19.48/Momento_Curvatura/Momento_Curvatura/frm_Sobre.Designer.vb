﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Sobre
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Sobre))
        Me.lbl14 = New System.Windows.Forms.Label()
        Me.lbl13 = New System.Windows.Forms.Label()
        Me.lbl12 = New System.Windows.Forms.Label()
        Me.lbl11 = New System.Windows.Forms.Label()
        Me.lbl10 = New System.Windows.Forms.Label()
        Me.lbl9 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl8 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lbl15 = New System.Windows.Forms.Label()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl14
        '
        Me.lbl14.AutoSize = True
        Me.lbl14.BackColor = System.Drawing.Color.Transparent
        Me.lbl14.ForeColor = System.Drawing.Color.White
        Me.lbl14.Location = New System.Drawing.Point(139, 507)
        Me.lbl14.Name = "lbl14"
        Me.lbl14.Size = New System.Drawing.Size(392, 13)
        Me.lbl14.TabIndex = 39
        Me.lbl14.Text = "O software tem por objetivo ser educacional, não possuindo, portanto, garantias. " &
    " "
        '
        'lbl13
        '
        Me.lbl13.AutoSize = True
        Me.lbl13.BackColor = System.Drawing.Color.Transparent
        Me.lbl13.ForeColor = System.Drawing.Color.White
        Me.lbl13.Location = New System.Drawing.Point(150, 494)
        Me.lbl13.Name = "lbl13"
        Me.lbl13.Size = New System.Drawing.Size(284, 13)
        Me.lbl13.TabIndex = 38
        Me.lbl13.Text = "da utilização do programa e/ou em futuras consequências."
        '
        'lbl12
        '
        Me.lbl12.AutoSize = True
        Me.lbl12.BackColor = System.Drawing.Color.Transparent
        Me.lbl12.ForeColor = System.Drawing.Color.White
        Me.lbl12.Location = New System.Drawing.Point(18, 481)
        Me.lbl12.Name = "lbl12"
        Me.lbl12.Size = New System.Drawing.Size(629, 13)
        Me.lbl12.TabIndex = 37
        Me.lbl12.Text = "Assim sendo, a Universidade e os autores aqui descritos estão isentos de qualquer" &
    " eventualidade ocasionado no presente momento"
        '
        'lbl11
        '
        Me.lbl11.AutoSize = True
        Me.lbl11.BackColor = System.Drawing.Color.Transparent
        Me.lbl11.ForeColor = System.Drawing.Color.White
        Me.lbl11.Location = New System.Drawing.Point(57, 468)
        Me.lbl11.Name = "lbl11"
        Me.lbl11.Size = New System.Drawing.Size(503, 13)
        Me.lbl11.TabIndex = 36
        Me.lbl11.Text = "resultados estes que correspondem ao cadastro de dados, saída dos dados e interpr" &
    "etação dos mesmos."
        '
        'lbl10
        '
        Me.lbl10.AutoSize = True
        Me.lbl10.BackColor = System.Drawing.Color.Transparent
        Me.lbl10.ForeColor = System.Drawing.Color.White
        Me.lbl10.Location = New System.Drawing.Point(18, 455)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(581, 13)
        Me.lbl10.TabIndex = 35
        Me.lbl10.Text = "Contudo, é válido ressaltar que o usuário (pessoa física ou jurídica) possui tota" &
    "l responsabilidade pelos resultados obtidos,"
        '
        'lbl9
        '
        Me.lbl9.AutoSize = True
        Me.lbl9.BackColor = System.Drawing.Color.Transparent
        Me.lbl9.ForeColor = System.Drawing.Color.White
        Me.lbl9.Location = New System.Drawing.Point(74, 425)
        Me.lbl9.Name = "lbl9"
        Me.lbl9.Size = New System.Drawing.Size(495, 13)
        Me.lbl9.TabIndex = 34
        Me.lbl9.Text = "Aos que usarem este programa como base de estudos e/ou trabalho, a sua utilização" &
    " é totalmente livre."
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.BackColor = System.Drawing.Color.Transparent
        Me.lbl4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4.ForeColor = System.Drawing.Color.White
        Me.lbl4.Location = New System.Drawing.Point(224, 254)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(261, 16)
        Me.lbl4.TabIndex = 31
        Me.lbl4.Text = "Ana Waldila de Queiroz Ramiro Reis"
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.BackColor = System.Drawing.Color.Transparent
        Me.lbl7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7.ForeColor = System.Drawing.Color.White
        Me.lbl7.Location = New System.Drawing.Point(285, 355)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(149, 16)
        Me.lbl7.TabIndex = 30
        Me.lbl7.Text = "Rodrigo Bird Burgos"
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.BackColor = System.Drawing.Color.Transparent
        Me.lbl6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6.ForeColor = System.Drawing.Color.White
        Me.lbl6.Location = New System.Drawing.Point(247, 326)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(220, 16)
        Me.lbl6.TabIndex = 29
        Me.lbl6.Text = "Margareth da Silva Magalhães"
        '
        'lbl8
        '
        Me.lbl8.AutoSize = True
        Me.lbl8.BackColor = System.Drawing.Color.Transparent
        Me.lbl8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8.ForeColor = System.Drawing.Color.White
        Me.lbl8.Location = New System.Drawing.Point(291, 404)
        Me.lbl8.Name = "lbl8"
        Me.lbl8.Size = New System.Drawing.Size(115, 16)
        Me.lbl8.TabIndex = 28
        Me.lbl8.Text = "Agosto de 2018"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.BackColor = System.Drawing.Color.Transparent
        Me.lbl5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5.ForeColor = System.Drawing.Color.White
        Me.lbl5.Location = New System.Drawing.Point(238, 297)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(238, 16)
        Me.lbl5.TabIndex = 27
        Me.lbl5.Text = "Com orientaçao dos professores:"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.BackColor = System.Drawing.Color.Transparent
        Me.lbl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3.ForeColor = System.Drawing.Color.White
        Me.lbl3.Location = New System.Drawing.Point(285, 238)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(139, 16)
        Me.lbl3.TabIndex = 26
        Me.lbl3.Text = "Desenvolvido por: "
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.BackColor = System.Drawing.Color.Transparent
        Me.lbl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2.ForeColor = System.Drawing.Color.White
        Me.lbl2.Location = New System.Drawing.Point(262, 222)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(172, 16)
        Me.lbl2.TabIndex = 22
        Me.lbl2.Text = "Versão Educacional 1.1"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.BackColor = System.Drawing.Color.Transparent
        Me.lbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.ForeColor = System.Drawing.Color.White
        Me.lbl1.Location = New System.Drawing.Point(126, 161)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(428, 16)
        Me.lbl1.TabIndex = 21
        Me.lbl1.Text = "AlfaMCV - Momento Curvatura em Vidas de Concreto Armado"
        Me.lbl1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(377, 12)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(124, 136)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 40
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(136, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(124, 136)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 41
        Me.PictureBox1.TabStop = False
        '
        'lbl15
        '
        Me.lbl15.AutoSize = True
        Me.lbl15.BackColor = System.Drawing.Color.Transparent
        Me.lbl15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl15.ForeColor = System.Drawing.Color.White
        Me.lbl15.Location = New System.Drawing.Point(262, 189)
        Me.lbl15.Name = "lbl15"
        Me.lbl15.Size = New System.Drawing.Size(187, 16)
        Me.lbl15.TabIndex = 42
        Me.lbl15.Text = "Faculdade de Engenharia"
        '
        'frm_Sobre
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(654, 541)
        Me.Controls.Add(Me.lbl15)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.lbl14)
        Me.Controls.Add(Me.lbl13)
        Me.Controls.Add(Me.lbl12)
        Me.Controls.Add(Me.lbl11)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.lbl9)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl7)
        Me.Controls.Add(Me.lbl6)
        Me.Controls.Add(Me.lbl8)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frm_Sobre"
        Me.Text = "Sobre o Software"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl14 As System.Windows.Forms.Label
    Friend WithEvents lbl13 As System.Windows.Forms.Label
    Friend WithEvents lbl12 As System.Windows.Forms.Label
    Friend WithEvents lbl11 As System.Windows.Forms.Label
    Friend WithEvents lbl10 As System.Windows.Forms.Label
    Friend WithEvents lbl9 As System.Windows.Forms.Label
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl7 As System.Windows.Forms.Label
    Friend WithEvents lbl6 As System.Windows.Forms.Label
    Friend WithEvents lbl8 As System.Windows.Forms.Label
    Friend WithEvents lbl5 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lbl15 As Label
End Class
