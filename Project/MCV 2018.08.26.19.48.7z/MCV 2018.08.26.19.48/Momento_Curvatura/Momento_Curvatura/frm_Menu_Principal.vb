﻿' MENU PRINCIPAL


Public Class frm_Menu_Principal

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        If PictureBox1.Top = 20 Then

            PictureBox1.Top = 20

            btn_ajuda.Visible = True
            btn_calculos.Visible = True
            btn_sobre.Visible = True
            btn_sair.Visible = True

        Else
            PictureBox1.Top = PictureBox1.Top + 1

        End If

    End Sub

    Private Sub btn_calculos_Click(sender As Object, e As EventArgs) Handles btn_calculos.Click

        frm_Calcula_Secao.Show()

    End Sub

    Private Sub btn_sair_Click(sender As Object, e As EventArgs) Handles btn_sair.Click

        If MessageBox.Show("Deseja sair da aplicaçao?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = vbYes Then

            Me.Close()

        End If

    End Sub

    Private Sub frm_Menu_Principal_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        btn_ajuda.Visible = False
        btn_calculos.Visible = False
        btn_sobre.Visible = False
        btn_sair.Visible = False

    End Sub

    Private Sub btn_ajuda_Click(sender As Object, e As EventArgs) Handles btn_ajuda.Click

        frm_Ajuda.Show()

    End Sub

    Private Sub btn_sobre_Click(sender As Object, e As EventArgs) Handles btn_sobre.Click

        frm_Sobre.Show()

    End Sub
End Class