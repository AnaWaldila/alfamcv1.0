﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Menu_Principal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Menu_Principal))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btn_calculos = New System.Windows.Forms.Button()
        Me.btn_sobre = New System.Windows.Forms.Button()
        Me.btn_ajuda = New System.Windows.Forms.Button()
        Me.btn_sair = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(22, -210)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(440, 217)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btn_calculos
        '
        Me.btn_calculos.BackColor = System.Drawing.Color.White
        Me.btn_calculos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_calculos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_calculos.ForeColor = System.Drawing.Color.Navy
        Me.btn_calculos.Location = New System.Drawing.Point(22, 249)
        Me.btn_calculos.Name = "btn_calculos"
        Me.btn_calculos.Size = New System.Drawing.Size(180, 40)
        Me.btn_calculos.TabIndex = 1
        Me.btn_calculos.Text = "Calcular"
        Me.btn_calculos.UseVisualStyleBackColor = False
        '
        'btn_sobre
        '
        Me.btn_sobre.BackColor = System.Drawing.Color.White
        Me.btn_sobre.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_sobre.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_sobre.ForeColor = System.Drawing.Color.Navy
        Me.btn_sobre.Location = New System.Drawing.Point(282, 249)
        Me.btn_sobre.Name = "btn_sobre"
        Me.btn_sobre.Size = New System.Drawing.Size(180, 40)
        Me.btn_sobre.TabIndex = 2
        Me.btn_sobre.Text = "Sobre o Software"
        Me.btn_sobre.UseVisualStyleBackColor = False
        '
        'btn_ajuda
        '
        Me.btn_ajuda.BackColor = System.Drawing.Color.White
        Me.btn_ajuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_ajuda.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ajuda.ForeColor = System.Drawing.Color.Navy
        Me.btn_ajuda.Location = New System.Drawing.Point(22, 300)
        Me.btn_ajuda.Name = "btn_ajuda"
        Me.btn_ajuda.Size = New System.Drawing.Size(180, 40)
        Me.btn_ajuda.TabIndex = 3
        Me.btn_ajuda.Text = "Ajuda"
        Me.btn_ajuda.UseVisualStyleBackColor = False
        '
        'btn_sair
        '
        Me.btn_sair.BackColor = System.Drawing.Color.White
        Me.btn_sair.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_sair.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_sair.ForeColor = System.Drawing.Color.Navy
        Me.btn_sair.Location = New System.Drawing.Point(282, 300)
        Me.btn_sair.Name = "btn_sair"
        Me.btn_sair.Size = New System.Drawing.Size(180, 40)
        Me.btn_sair.TabIndex = 4
        Me.btn_sair.Text = "Sair"
        Me.btn_sair.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1
        '
        'frm_Menu_Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(484, 361)
        Me.Controls.Add(Me.btn_sair)
        Me.Controls.Add(Me.btn_ajuda)
        Me.Controls.Add(Me.btn_sobre)
        Me.Controls.Add(Me.btn_calculos)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_Menu_Principal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu Principal"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btn_calculos As System.Windows.Forms.Button
    Friend WithEvents btn_sobre As System.Windows.Forms.Button
    Friend WithEvents btn_ajuda As System.Windows.Forms.Button
    Friend WithEvents btn_sair As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
