﻿Imports System.Math

Module Modulo_Calculo_Secao_Retangular_Estadio1

    'VARIAVEIS CONCRETO

    Public fck As Double
    Public ftk As Double
    Public Ec As Double
    Public etm As Double
    Public ecm As Double
    Public ecp As Double
    Public L As Double
    Public deflexao_estadio1 As Double
    Public comprimento_vao As Double

    'VARIAVEIS AÇO

    Public aco_compressao As Double
    Public aco_tracao As Double
    Public Es As Double
    Public es2_estadio1 As Double
    Public es1_estadio1 As Double

    'VARIAVEIS SECAO

    Public altura_total As Double
    Public altura_util As Double
    Public largura_maior As Double

    'VARIAVEL LN

    Public LN_estadio1 As Double

    'VARIAVEIS COEFICIENTES

    Public A_estadio1 As Double
    Public B_estadio1 As Double
    Public Q_estadio1 As Double

    Public k1_estadio1 As Double
    Public k1_estadio1_parte1 As Double
    Public k1_estadio1_parte2 As Double

    Public k2_estadio1 As Double
    Public k2_estadio1_parte1 As Double
    Public k2_estadio1_parte2 As Double
    Public k2_estadio1_parte3 As Double
    Public k2_estadio1_parte4 As Double

    Public k3_estadio1 As Double

    Public k4_estadio1 As Double

    'VARIAVEL MOMENTO

    Public momento_estadio1 As Double
    Public momento_linear_estadio1 As Double

    ' CALCULO DEFORMACOES

    Function Funcao_etp_Rec_Estadio1() As Double

        etm = ftk / Ec

        Return etm

    End Function


    Function Funcao_ecm_Rec_Estadio1() As Double

        ecm = Funcao_etp_Rec_Estadio1() * Funcao_LN_Estadio1() / _
            (altura_total - Funcao_LN_Estadio1())

        Return ecm

    End Function


    Function Funcao_etm_Rec_Estadio1() As Double

        etm = (altura_total - Funcao_LN_Estadio1()) * Funcao_ecm_Rec_Estadio1() / Funcao_LN_Estadio1()

        Return etm

    End Function


    Function Funcao_es2_Rec_Estadio1() As Double

        es2_estadio1 = (altura_util - Funcao_LN_Estadio1()) * Funcao_etp_Rec_Estadio1() / _
                        (altura_total - Funcao_LN_Estadio1())

        Return es2_estadio1

    End Function


    Function Funcao_es1_Rec_Estadio1() As Double

        If frm_Calcula_Secao.txt_aco_compressao.Text > 0 Then

            es1_estadio1 = (Funcao_LN_Estadio1() - _
            (altura_total - altura_util)) * Funcao_etp_Rec_Estadio1() / _
            (altura_total - Funcao_LN_Estadio1())

        Else

            es1_estadio1 = 0

        End If

        Return es1_estadio1

    End Function


    Function Funcao_ecp_Rec_Estadio1() As Double

        ecp = 2 * fck / Ec

        Return ecp

    End Function


    ' COEFICIENTES A, B, Q, K1, K2, K3, K4

    Function Funcao_A_Rec_Estadio1() As Double

        A_estadio1 = ((Ec * Funcao_ecp_Rec_Estadio1() / fck) - 2) / Funcao_ecp_Rec_Estadio1()

        Return A_estadio1

    End Function


    Function Funcao_B_Rec_Estadio1() As Double

        B_estadio1 = 1 / (Funcao_ecp_Rec_Estadio1() ^ 2)

        Return B_estadio1

    End Function


    Function Funcao_Q_rec_Estadio1() As Double

        Q_estadio1 = 4 * Funcao_B_Rec_Estadio1() - Funcao_A_Rec_Estadio1() * Funcao_A_Rec_Estadio1()

        Return Q_estadio1

    End Function


    Function Funcao_k1_Rec_Estadio1() As Double

        k1_estadio1_parte1 = (0.5 / Funcao_B_Rec_Estadio1()) * _
        (Math.Log(1 + Funcao_A_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1() + _
 Funcao_B_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1()))


        k1_estadio1_parte2 = (Funcao_A_Rec_Estadio1() / (Funcao_B_Rec_Estadio1() * Math.Sqrt(Funcao_Q_rec_Estadio1))) * _
                (Math.Atan(Funcao_A_Rec_Estadio1() / Math.Sqrt(Funcao_Q_rec_Estadio1)) -
                Math.Atan((Funcao_A_Rec_Estadio1() + _
                2 * Funcao_B_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1()) / _
                Math.Sqrt(Funcao_Q_rec_Estadio1)))

        k1_estadio1 = (Ec / (fck * Funcao_ecm_Rec_Estadio1())) * (k1_estadio1_parte1 + k1_estadio1_parte2)


        Return k1_estadio1

    End Function


    Function Funcao_k2_Rec_Estadio1() As Double

        k2_estadio1_parte1 = (Funcao_A_Rec_Estadio1() * 0.5 / (Funcao_B_Rec_Estadio1() * Funcao_B_Rec_Estadio1())) * _
        Math.Log(1 + Funcao_A_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1() + Funcao_B_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1())

        k2_estadio1_parte2 = ((Funcao_A_Rec_Estadio1() * Funcao_A_Rec_Estadio1() - 2 * Funcao_B_Rec_Estadio1()) / _
        (Funcao_B_Rec_Estadio1() * Funcao_B_Rec_Estadio1() * Math.Sqrt(Funcao_Q_rec_Estadio1))) * _
        (Math.Atan((2 * Funcao_B_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1() + Funcao_A_Rec_Estadio1()) / Math.Sqrt(Funcao_Q_rec_Estadio1)) - _
                Math.Atan(Funcao_A_Rec_Estadio1() / Math.Sqrt(Funcao_Q_rec_Estadio1)))

        k2_estadio1_parte3 = (0.5 / Funcao_B_Rec_Estadio1()) * _
        (Math.Log(1 + Funcao_A_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1() + _
Funcao_B_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1()))

        k2_estadio1_parte4 = (Funcao_A_Rec_Estadio1() / (Funcao_B_Rec_Estadio1() * Math.Sqrt(Funcao_Q_rec_Estadio1))) * _
        (Math.Atan(Funcao_A_Rec_Estadio1() / Math.Sqrt(Funcao_Q_rec_Estadio1)) -
        Math.Atan((Funcao_A_Rec_Estadio1() + 2 * Funcao_B_Rec_Estadio1() * Funcao_ecm_Rec_Estadio1()) / Math.Sqrt(Funcao_Q_rec_Estadio1)))

        k2_estadio1 = 1 - (((Funcao_ecm_Rec_Estadio1() / Funcao_B_Rec_Estadio1()) - k2_estadio1_parte1 + k2_estadio1_parte2) / (Funcao_ecm_Rec_Estadio1() * (k2_estadio1_parte3 + k2_estadio1_parte4)))

        Return k2_estadio1

    End Function


    Function Funcao_k3_Rec_Estadio1() As Double

        k3_estadio1 = Ec * Funcao_etp_Rec_Estadio1() / (2 * ftk)

        Return k3_estadio1

    End Function


    Function Funcao_k4_Rec_Estadio1() As Double

        k4_estadio1 = 1 / 3

        Return k4_estadio1

    End Function



    ' CALCULOS SECAO ESTADIO 1 


    ' CALCULO LN 

    Function Funcao_LN_Estadio1() As Double

        LN_estadio1 = (2 * (Es / Ec) * (altura_util * (aco_tracao - aco_compressao) + altura_total * aco_compressao) + _
                largura_maior * altura_total * altura_total) / _
          (2 * (altura_total * largura_maior + (Es / Ec) * aco_tracao + (Es / Ec) * aco_compressao))

        Return LN_estadio1

    End Function


    ' CALCULO MOMENTO

    Function Funcao_Momento_Rec_Estadio1() As Double

        momento_estadio1 = Funcao_k1_Rec_Estadio1() * fck * largura_maior * 10 * Funcao_LN_Estadio1() * 10 * (altura_total * 0.5 * 10 - Funcao_k2_Rec_Estadio1() * Funcao_LN_Estadio1() * 10) + _
        Funcao_es2_Rec_Estadio1() * Es * aco_tracao * 100 * (altura_util * 10 - altura_total * 0.5 * 10) + _
        Funcao_es1_Rec_Estadio1() * Es * aco_compressao * 100 * (altura_util * 10 - altura_total * 0.5 * 10) + _
        Funcao_k3_Rec_Estadio1() * ftk * largura_maior * 10 * (altura_total * 10 - Funcao_LN_Estadio1() * 10) * (altura_total * 0.5 * 10 - Funcao_k4_Rec_Estadio1() * (altura_total * 10 - Funcao_LN_Estadio1() * 10))

        Return momento_estadio1 * 0.000001

    End Function

    ' CALCULO DEFLEXAO

    Function Funcao_Deflexao_Estadio1() As Double

        deflexao_estadio1 = (comprimento_vao ^ 2) * Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1 / (12 * Funcao_LN_Estadio1())

        Return deflexao_estadio1

    End Function


    ' FIM CALCULOS SECAO ESTADIO 1 

End Module
