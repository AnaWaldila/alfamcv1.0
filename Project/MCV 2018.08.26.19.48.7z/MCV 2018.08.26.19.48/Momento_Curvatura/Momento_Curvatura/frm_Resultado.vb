﻿' RESULTADO

Imports System.Windows.Forms.DataVisualization.Charting
Imports Microsoft.Office.Interop

Public Class frm_Resultado

    Public eixo_ecm_estadio1() As Double = {0, Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_ecm_Rec_Estadio1}

    Public eixo_momento_estadio1() As Double = {0, Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Momento_Rec_Estadio1}

    Public eixo_es1_estadio1() As Double = {0, Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_es1_Rec_Estadio1}

    Public eixo_es2_estadio1() As Double = {0, Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_es2_Rec_Estadio1}

    Public eixo_etm_estadio1() As Double = {0, Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_etm_Rec_Estadio1}

    Public eixo_LN_estadio1() As Double = {altura_total, Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_LN_Estadio1}

    Public eixo_deflexao_estadio1() As Double = {0, Modulo_Calculo_Secao_Retangular_Estadio1.Funcao_Deflexao_Estadio1}

    Public QtdTotaLinha As Int64 = 0

    Private Sub frm_Resultado_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.txt_resultado_Aco_compressao.Enabled = False
        Me.txt_resultado_aco_tracao.Enabled = False
        Me.txt_resultado_compressao_concreto.Enabled = False
        Me.txt_resultado_compressao_maxima_concreto.Enabled = False
        Me.txt_resultado_deformacao_tracao_concreto.Enabled = False
        Me.txt_resultado_LN.Enabled = False
        Me.txt_resultado_momento_fissuracao.Enabled = False

    End Sub

    Private Sub ExportarParaExcelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExportarParaExcelToolStripMenuItem.Click

        Me.ExportarParaExcel()



    End Sub

    Private Sub ExportarParaExcel()
        Dim xlApp As Excel.Application = New Excel.Application
        Dim xlWorkBook As Excel.Workbook
        Dim xlWorkSheet As Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value

        xlWorkBook = xlApp.Workbooks.Add(misValue)
        xlWorkSheet = CType(xlWorkBook.Sheets(1), Excel.Worksheet)
        With xlWorkSheet

            'Titulo das colunas

            .Cells(1, 1) = "índice i"
            .Cells(1, 2) = "Tipo de Regime"
            .Cells(1, 3) = "Linha Neutra (cm)"
            .Cells(1, 4) = "Deformação Compressão do Concreto (por mil)"
            .Cells(1, 5) = "Deformação Compressão do Aço (por mil)"
            .Cells(1, 6) = "Deformação Tração do Aço (por mil)"
            .Cells(1, 7) = "Momento (kN.m)"
            .Cells(1, 8) = "Deflexão (cm)"

            'Titulo das colunas em negrito

            .Range("A1", "A1").Font.Bold = True
            .Range("B1", "B1").Font.Bold = True
            .Range("C1", "C1").Font.Bold = True
            .Range("D1", "D1").Font.Bold = True
            .Range("E1", "E1").Font.Bold = True
            .Range("F1", "F1").Font.Bold = True
            .Range("G1", "G1").Font.Bold = True
            .Range("H1", "H1").Font.Bold = True

        End With

        For linha As Integer = 0 To DataGrid_Resultado_Estadio2.Rows.Count - 1
            For coluna As Integer = 0 To DataGrid_Resultado_Estadio2.Columns.Count - 1
                xlWorkSheet.Cells(linha + 2, coluna + 1) = DataGrid_Resultado_Estadio2.Rows(linha).Cells(coluna).Value
            Next
        Next

        xlApp.Visible = True

        'xlWorkBook.SaveAs("Resultado_AlfaMCV")
        'xlWorkBook.Close()
        'xlApp.Quit()

        'MessageBox.Show("Arquivo Tabela_Resultados_AlfaMCV.xlsx criado com sucesso!", _
        '                "AlfaMCV")
    End Sub

    Private Sub MenuPrincipalToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MenuPrincipalToolStripMenuItem.Click

        frm_Menu_Principal.Show()

        Me.Close()


    End Sub

    Private Sub AjudaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AjudaToolStripMenuItem.Click

        frm_Ajuda.Show()

        Me.Close()

    End Sub
End Class